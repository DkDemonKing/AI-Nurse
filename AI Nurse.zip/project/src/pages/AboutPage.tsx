import React from 'react';
import { motion } from 'framer-motion';
import { Heart, Award, Star, Shield, Coffee } from 'lucide-react';
import ContactSection from '../components/ContactSection';

const AboutPage: React.FC = () => {
  // Team members data
  const teamMembers = [
    {
      name: 'Dr. Emily Chen',
      role: 'Chief Nursing Officer',
      bio: 'With over 15 years of experience in healthcare leadership, Dr. Chen oversees all nursing operations and ensures the highest standards of care.',
      image: 'https://images.pexels.com/photos/5452201/pexels-photo-5452201.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    },
    {
      name: 'Michael Rodriguez, RN',
      role: 'Director of Home Care Services',
      bio: 'Michael specializes in home healthcare coordination and has pioneered several innovative approaches to patient care in home settings.',
      image: 'https://images.pexels.com/photos/5327656/pexels-photo-5327656.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    },
    {
      name: 'Sarah Johnson, BSN',
      role: 'Pediatric Nursing Specialist',
      bio: 'With a passion for pediatric care, Sarah has dedicated her career to providing exceptional nursing services for children and their families.',
      image: 'https://images.pexels.com/photos/5214952/pexels-photo-5214952.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    },
    {
      name: 'James Williams, RN',
      role: 'Geriatric Care Coordinator',
      bio: 'James focuses on creating compassionate care plans for elderly patients, emphasizing dignity and quality of life in every interaction.',
      image: 'https://images.pexels.com/photos/5327585/pexels-photo-5327585.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    }
  ];
  
  // Values data
  const values = [
    {
      icon: Heart,
      title: 'Compassion',
      description: 'We approach every patient with genuine care and empathy, understanding that kindness is as important as clinical expertise.'
    },
    {
      icon: Award,
      title: 'Excellence',
      description: 'We strive for the highest standards in nursing practice, continuously improving our skills and knowledge.'
    },
    {
      icon: Star,
      title: 'Innovation',
      description: 'We embrace new technologies and methodologies to enhance patient care and healthcare outcomes.'
    },
    {
      icon: Shield,
      title: 'Integrity',
      description: 'We uphold the highest ethical standards, ensuring honesty and transparency in all our interactions.'
    },
    {
      icon: Coffee,
      title: 'Dedication',
      description: 'We are committed to providing exceptional care and support to every patient, every time.'
    }
  ];
  
  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="relative py-16 bg-primary/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-6">About Us</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
              Learn about our mission, our team, and our commitment to excellence in nursing care.
            </p>
          </motion.div>
        </div>
      </section>
      
      {/* Our Story Section */}
      <section className="section">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-bold mb-6">Our Story</h2>
            <p className="text-gray-600 mb-4">
              FlorAlges Nursing was founded in 2010 with a simple yet powerful mission: to revolutionize 
              the way nursing care is delivered. Our founder, Dr. Emily Chen, recognized the need for a 
              more personal, tech-enabled approach to healthcare that puts patients first.
            </p>
            <p className="text-gray-600 mb-4">
              The name "FlorAlges" combines "Flora" (meaning growth and vitality) with "Alges" (derived from 
              healthcare roots), reflecting our commitment to nurturing health and alleviating discomfort 
              through expert nursing care.
            </p>
            <p className="text-gray-600">
              Over the years, we've grown from a small team of dedicated nurses to a comprehensive 
              healthcare provider, but our core values remain unchanged. We believe in providing 
              care that is not only clinically excellent but also compassionate and personalized.
            </p>
            <div className="mt-8">
              <h3 className="text-xl font-bold mb-4">Our Mission</h3>
              <p className="text-gray-600">
                To provide exceptional nursing care that enhances the quality of life for our patients, 
                delivered with compassion, integrity, and clinical excellence.
              </p>
            </div>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            viewport={{ once: true }}
            className="relative"
          >
            <img 
              src="https://images.pexels.com/photos/6129507/pexels-photo-6129507.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
              alt="Nursing Team" 
              className="rounded-xl shadow-xl"
            />
            <div className="absolute -bottom-6 -left-6 bg-white p-4 rounded-lg shadow-lg">
              <p className="text-primary font-bold italic">"Born in code, tested with care."</p>
            </div>
          </motion.div>
        </div>
      </section>
      
      {/* Values Section */}
      <section className="py-16 bg-primary/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Core Values</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              These principles guide every aspect of our practice and define who we are as healthcare professionals.
            </p>
          </motion.div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-8">
            {values.map((value, index) => {
              const Icon = value.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className="card text-center"
                >
                  <div className="inline-block bg-primary/10 p-4 rounded-full mb-4">
                    <Icon size={24} className="text-primary" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">{value.title}</h3>
                  <p className="text-gray-600">{value.description}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>
      
      {/* Team Section */}
      <section className="section">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Leadership Team</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Meet the dedicated professionals who lead our nursing team and ensure excellence in everything we do.
          </p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {teamMembers.map((member, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="card text-center"
            >
              <div className="mb-4 overflow-hidden rounded-full w-32 h-32 mx-auto">
                <img 
                  src={member.image} 
                  alt={member.name} 
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-xl font-bold mb-1">{member.name}</h3>
              <p className="text-primary font-medium mb-3">{member.role}</p>
              <p className="text-gray-600">{member.bio}</p>
            </motion.div>
          ))}
        </div>
      </section>
      
      {/* Certifications Section */}
      <section className="py-16 bg-primary/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Certifications</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              We maintain the highest standards through recognized certifications and continuous education.
            </p>
          </motion.div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              viewport={{ once: true }}
              className="card"
            >
              <h3 className="text-xl font-bold mb-4">Healthcare Accreditations</h3>
              <ul className="space-y-3">
                <li className="flex items-center">
                  <div className="bg-primary/10 p-2 rounded-full mr-3">
                    <Shield size={18} className="text-primary" />
                  </div>
                  <span>Joint Commission Accreditation</span>
                </li>
                <li className="flex items-center">
                  <div className="bg-primary/10 p-2 rounded-full mr-3">
                    <Shield size={18} className="text-primary" />
                  </div>
                  <span>CHAP (Community Health Accreditation Partner)</span>
                </li>
                <li className="flex items-center">
                  <div className="bg-primary/10 p-2 rounded-full mr-3">
                    <Shield size={18} className="text-primary" />
                  </div>
                  <span>Medicare Certified</span>
                </li>
                <li className="flex items-center">
                  <div className="bg-primary/10 p-2 rounded-full mr-3">
                    <Shield size={18} className="text-primary" />
                  </div>
                  <span>State Department of Health Licensure</span>
                </li>
              </ul>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              viewport={{ once: true }}
              className="card"
            >
              <h3 className="text-xl font-bold mb-4">Our Commitment to Excellence</h3>
              <ul className="space-y-3">
                <li className="flex items-center">
                  <div className="bg-primary/10 p-2 rounded-full mr-3">
                    <Award size={18} className="text-primary" />
                  </div>
                  <span>Annual competency evaluations for all nursing staff</span>
                </li>
                <li className="flex items-center">
                  <div className="bg-primary/10 p-2 rounded-full mr-3">
                    <Award size={18} className="text-primary" />
                  </div>
                  <span>Continuing education requirements exceed industry standards</span>
                </li>
                <li className="flex items-center">
                  <div className="bg-primary/10 p-2 rounded-full mr-3">
                    <Award size={18} className="text-primary" />
                  </div>
                  <span>Rigorous background checks and credential verification</span>
                </li>
                <li className="flex items-center">
                  <div className="bg-primary/10 p-2 rounded-full mr-3">
                    <Award size={18} className="text-primary" />
                  </div>
                  <span>Regular quality assurance reviews and patient satisfaction surveys</span>
                </li>
              </ul>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Contact Section */}
      <ContactSection />
    </div>
  );
};

export default AboutPage;