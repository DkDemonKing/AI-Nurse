import React from 'react';
import { motion } from 'framer-motion';
import { Phone, Mail, MapPin, Clock, MessageSquare, Calendar, FileQuestion } from 'lucide-react';

const ContactPage: React.FC = () => {
  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="relative py-16 bg-primary/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Contact Us</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
              We're here to answer your questions and provide the support you need.
            </p>
          </motion.div>
        </div>
      </section>
      
      {/* Main Contact Section */}
      <section className="section">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Information */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl font-bold mb-8">Get in Touch</h2>
            
            <div className="space-y-6 mb-8">
              <div className="flex items-start">
                <div className="bg-primary/10 p-4 rounded-full mr-4">
                  <Phone size={24} className="text-primary" />
                </div>
                <div>
                  <h4 className="text-xl font-medium mb-2">Call Us</h4>
                  <p className="text-gray-600">General Inquiries: (123) 456-7890</p>
                  <p className="text-gray-600">Emergency Line: (123) 456-8888</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="bg-primary/10 p-4 rounded-full mr-4">
                  <Mail size={24} className="text-primary" />
                </div>
                <div>
                  <h4 className="text-xl font-medium mb-2">Email Us</h4>
                  <p className="text-gray-600">General Inquiries: info@floralgesnursing.com</p>
                  <p className="text-gray-600">Patient Support: care@floralgesnursing.com</p>
                  <p className="text-gray-600">Careers: careers@floralgesnursing.com</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="bg-primary/10 p-4 rounded-full mr-4">
                  <MapPin size={24} className="text-primary" />
                </div>
                <div>
                  <h4 className="text-xl font-medium mb-2">Visit Us</h4>
                  <p className="text-gray-600">Main Office:</p>
                  <p className="text-gray-600">123 Healthcare Avenue</p>
                  <p className="text-gray-600">Medical District, FL 12345</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="bg-primary/10 p-4 rounded-full mr-4">
                  <Clock size={24} className="text-primary" />
                </div>
                <div>
                  <h4 className="text-xl font-medium mb-2">Working Hours</h4>
                  <p className="text-gray-600">Monday - Friday: 8:00 AM - 8:00 PM</p>
                  <p className="text-gray-600">Saturday: 9:00 AM - 5:00 PM</p>
                  <p className="text-gray-600">Sunday: Emergency Services Only</p>
                  <p className="text-gray-600 font-medium mt-2">24/7 Emergency Nursing: Always Available</p>
                </div>
              </div>
            </div>
            
            {/* Map */}
            <div className="rounded-xl overflow-hidden shadow-lg h-64 bg-gray-200 mt-8">
              <div className="w-full h-full bg-gray-300 flex items-center justify-center">
                <p className="text-gray-500">Interactive Map</p>
                {/* Would typically embed a Google Map or similar here */}
              </div>
            </div>
          </motion.div>
          
          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            viewport={{ once: true }}
            className="card"
          >
            <h2 className="text-3xl font-bold mb-8">Send Us a Message</h2>
            <form className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 mb-1">
                    First Name*
                  </label>
                  <input
                    type="text"
                    id="firstName"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-primary focus:border-primary"
                    placeholder="John"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 mb-1">
                    Last Name*
                  </label>
                  <input
                    type="text"
                    id="lastName"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-primary focus:border-primary"
                    placeholder="Doe"
                    required
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                    Email Address*
                  </label>
                  <input
                    type="email"
                    id="email"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-primary focus:border-primary"
                    placeholder="john@example.com"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                    Phone Number*
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-primary focus:border-primary"
                    placeholder="(123) 456-7890"
                    required
                  />
                </div>
              </div>
              
              <div>
                <label htmlFor="inquiryType" className="block text-sm font-medium text-gray-700 mb-1">
                  Type of Inquiry*
                </label>
                <select
                  id="inquiryType"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-primary focus:border-primary"
                  required
                >
                  <option value="" disabled selected>Select an option</option>
                  <option value="services">Nursing Services</option>
                  <option value="appointment">Schedule Appointment</option>
                  <option value="billing">Billing Questions</option>
                  <option value="feedback">Provide Feedback</option>
                  <option value="career">Career Opportunities</option>
                  <option value="other">Other</option>
                </select>
              </div>
              
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                  Message*
                </label>
                <textarea
                  id="message"
                  rows={5}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-primary focus:border-primary"
                  placeholder="Please provide details about your inquiry..."
                  required
                ></textarea>
              </div>
              
              <div className="flex items-start">
                <input
                  type="checkbox"
                  id="privacy"
                  className="mt-1 mr-2"
                  required
                />
                <label htmlFor="privacy" className="text-sm text-gray-600">
                  I agree to the <a href="#" className="text-primary hover:underline">Privacy Policy</a> and consent to having my data processed for the purpose of contacting me.
                </label>
              </div>
              
              <button
                type="submit"
                className="btn-primary w-full"
              >
                Submit Message
              </button>
            </form>
          </motion.div>
        </div>
      </section>
      
      {/* Quick Contact Options */}
      <section className="py-16 bg-primary/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Quick Contact Options</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Choose the most convenient way to reach us based on your needs.
            </p>
          </motion.div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: MessageSquare,
                title: 'Live Chat',
                description: 'Chat with our support team for immediate assistance during business hours.',
                buttonText: 'Start Chat',
                buttonLink: '#'
              },
              {
                icon: Calendar,
                title: 'Schedule Call',
                description: 'Book a phone consultation with one of our nursing professionals.',
                buttonText: 'Schedule Now',
                buttonLink: '#'
              },
              {
                icon: FileQuestion,
                title: 'FAQ',
                description: 'Find answers to common questions about our services and processes.',
                buttonText: 'View FAQs',
                buttonLink: '#'
              }
            ].map((option, index) => {
              const Icon = option.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.2 }}
                  viewport={{ once: true }}
                  className="card text-center"
                >
                  <div className="inline-block bg-primary/10 p-4 rounded-full mb-4">
                    <Icon size={28} className="text-primary" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">{option.title}</h3>
                  <p className="text-gray-600 mb-6">{option.description}</p>
                  <a
                    href={option.buttonLink}
                    className="bg-white text-primary border border-primary hover:bg-primary hover:text-white font-medium py-2 px-4 rounded-lg transition-colors inline-block"
                  >
                    {option.buttonText}
                  </a>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="section">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="bg-primary rounded-xl p-8 md:p-12 text-center text-white"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Need Immediate Assistance?</h2>
          <p className="text-lg mb-8 max-w-3xl mx-auto">
            Our nursing professionals are available 24/7 for emergency situations.
            Don't hesitate to call our emergency line for immediate help.
          </p>
          <div className="flex flex-col sm:flex-row justify-center items-center gap-4">
            <a
              href="tel:1234568888"
              className="bg-white text-primary hover:bg-gray-100 font-bold py-3 px-8 rounded-lg flex items-center justify-center transition-colors"
            >
              <Phone size={20} className="mr-2" />
              (123) 456-8888
            </a>
            <a
              href="#"
              className="bg-transparent border-2 border-white hover:bg-white hover:text-primary text-white font-bold py-3 px-8 rounded-lg transition-colors"
            >
              Learn About Emergency Services
            </a>
          </div>
        </motion.div>
      </section>
    </div>
  );
};

export default ContactPage;