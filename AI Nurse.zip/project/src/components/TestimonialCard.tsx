import React from 'react';
import { motion } from 'framer-motion';
import { Quote } from 'lucide-react';

interface TestimonialCardProps {
  quote: string;
  author: string;
  role: string;
  image: string;
  delay?: number;
}

const TestimonialCard: React.FC<TestimonialCardProps> = ({ 
  quote, 
  author, 
  role, 
  image,
  delay = 0 
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
      viewport={{ once: true }}
      className="card text-center"
    >
      <div className="flex justify-center mb-4">
        <div className="relative">
          <img
            src={image}
            alt={author}
            className="w-20 h-20 rounded-full object-cover border-2 border-primary"
          />
          <div className="absolute -top-2 -right-2 bg-primary rounded-full p-1 text-white">
            <Quote size={16} />
          </div>
        </div>
      </div>
      <p className="text-gray-600 italic mb-4">"{quote}"</p>
      <p className="font-bold">{author}</p>
      <p className="text-sm text-gray-500">{role}</p>
    </motion.div>
  );
};

export default TestimonialCard;