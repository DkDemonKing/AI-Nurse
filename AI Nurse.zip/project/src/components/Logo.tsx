import React from 'react';
import { Activity } from 'lucide-react';

interface LogoProps {
  className?: string;
}

const Logo: React.FC<LogoProps> = ({ className = 'h-10 w-10' }) => {
  return (
    <div className={`relative ${className}`}>
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="text-[#457B9D]">
          <Activity strokeWidth={2} className="w-full h-full" />
        </div>
      </div>
      <div className="absolute inset-0">
        <div className="w-full h-full relative">
          {/* Left Wing */}
          <div className="absolute left-0 top-1/2 w-1/3 h-1/4 bg-[#E5C1F0] transform -translate-y-1/2 rounded-l-full" />
          {/* Right Wing */}
          <div className="absolute right-0 top-1/2 w-1/3 h-1/4 bg-[#457B9D] transform -translate-y-1/2 rounded-r-full" />
          {/* Center Staff */}
          <div className="absolute left-1/2 top-0 w-[2px] h-full bg-[#2A9D8F] transform -translate-x-1/2" />
          {/* Red Cross */}
          <div className="absolute left-1/2 top-0 transform -translate-x-1/2 -translate-y-1/2">
            <div className="bg-[#E63946] rounded-full p-1">
              <div className="w-3 h-3 text-white flex items-center justify-center">+</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Logo;