import React from 'react';
import { motion } from 'framer-motion';
import { Users, Award, Calendar, Heart } from 'lucide-react';

const statsData = [
  { 
    icon: Users, 
    value: '10,000+', 
    label: 'Patients Served', 
    color: 'text-primary' 
  },
  { 
    icon: Award, 
    value: '50+', 
    label: 'Certified Nurses', 
    color: 'text-secondary' 
  },
  { 
    icon: Calendar, 
    value: '15+', 
    label: 'Years Experience', 
    color: 'text-accent' 
  },
  { 
    icon: Heart, 
    value: '98%', 
    label: 'Satisfaction Rate', 
    color: 'text-primary' 
  },
];

const StatsSection: React.FC = () => {
  return (
    <section className="py-14 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
        >
          {statsData.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <div 
                key={index} 
                className="card text-center hover:-translate-y-2 transition-transform"
              >
                <div className="flex justify-center mb-3">
                  <Icon size={32} className={stat.color} />
                </div>
                <h3 className="text-3xl font-bold mb-2">{stat.value}</h3>
                <p className="text-gray-600">{stat.label}</p>
              </div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
};

export default StatsSection;