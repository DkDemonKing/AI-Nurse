import React from 'react';
import { motion } from 'framer-motion';
import { DivideIcon as LucideIcon } from 'lucide-react';

interface ServiceCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
  delay?: number;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ 
  title, 
  description, 
  icon: Icon,
  delay = 0 
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
      viewport={{ once: true }}
      className="card hover:shadow-xl group"
    >
      <div className="mb-4 bg-primary/10 p-4 rounded-full inline-block group-hover:bg-primary/20 transition-colors">
        <Icon size={28} className="text-primary" />
      </div>
      <h3 className="text-xl font-bold mb-3">{title}</h3>
      <p className="text-gray-600">{description}</p>
      <div className="mt-4">
        <button className="text-primary font-medium flex items-center group-hover:underline">
          Learn more
        </button>
      </div>
    </motion.div>
  );
};

export default ServiceCard;