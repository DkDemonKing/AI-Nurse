import React, { useState } from 'react';
import { motion } from 'framer-motion';

interface PatientProfile {
  name: string;
  age: string;
  symptoms: string;
  medicalHistory: string;
  gender: string;
  biometricScan: boolean;
}

const PatientProfilePage: React.FC = () => {
  const [profile, setProfile] = useState<PatientProfile>({
    name: '',
    age: '',
    symptoms: '',
    medicalHistory: '',
    gender: '',
    biometricScan: false,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Patient Profile:', profile);
    // Handle form submission here
  };

  return (
    <div className="pt-20 min-h-screen bg-light">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="bg-white rounded-xl shadow-lg p-8"
        >
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-primary mb-2">PATIENT'S PROFILE</h1>
            <p className="text-gray-600">Please fill in your information below</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-bold mb-2">ENTER YOUR NAME:</label>
                <input
                  type="text"
                  value={profile.name}
                  onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-bold mb-2">ENTER YOUR AGE:</label>
                <input
                  type="number"
                  value={profile.age}
                  onChange={(e) => setProfile({ ...profile, age: e.target.value })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-bold mb-2">SYMPTOMS:</label>
              <textarea
                value={profile.symptoms}
                onChange={(e) => setProfile({ ...profile, symptoms: e.target.value })}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                rows={3}
                required
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-bold mb-2">MEDICAL HISTORY:</label>
                <textarea
                  value={profile.medicalHistory}
                  onChange={(e) => setProfile({ ...profile, medicalHistory: e.target.value })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                  rows={3}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-bold mb-2">GENDER:</label>
                <select
                  value={profile.gender}
                  onChange={(e) => setProfile({ ...profile, gender: e.target.value })}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                  required
                >
                  <option value="">Select Gender</option>
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                  <option value="other">Other</option>
                </select>
              </div>
            </div>

            <div>
              <label className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  checked={profile.biometricScan}
                  onChange={(e) => setProfile({ ...profile, biometricScan: e.target.checked })}
                  className="w-5 h-5 text-primary rounded focus:ring-primary"
                />
                <span className="text-sm font-bold">BIOMETRIC SCAN/SECURE LOGIN</span>
              </label>
            </div>

            <div className="flex justify-center pt-6">
              <button
                type="submit"
                className="btn-primary w-full md:w-auto md:px-12"
              >
                Submit Profile
              </button>
            </div>
          </form>
        </motion.div>
      </div>
    </div>
  );
};

export default PatientProfilePage;