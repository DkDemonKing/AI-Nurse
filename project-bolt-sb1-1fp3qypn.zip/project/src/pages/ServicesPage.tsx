import React from 'react';
import { motion } from 'framer-motion';
import { Heart, Users, Clock, Sparkles, UserPlus, ShieldCheck, Brain, Thermometer } from 'lucide-react';
import ContactSection from '../components/ContactSection';

const ServicesPage: React.FC = () => {
  // Detailed services data
  const detailedServices = [
    {
      icon: Heart,
      title: 'Home Healthcare',
      description: 'Professional nursing care in the comfort of your own home, tailored to your specific health needs.',
      details: [
        'Personalized care plans designed for individual patient needs',
        'Medication management and administration',
        'Wound care and dressing changes',
        'Vital signs monitoring and health assessments',
        'Assistance with activities of daily living (ADLs)'
      ]
    },
    {
      icon: Users,
      title: 'Hospital Staffing',
      description: 'Providing qualified nursing professionals to hospitals and medical facilities to ensure quality patient care.',
      details: [
        'Short-term and long-term staffing solutions',
        'Emergency coverage for unexpected staff shortages',
        'Specialty nurses for specialized departments',
        'Seamless integration with existing healthcare teams',
        'Quality assurance and performance monitoring'
      ]
    },
    {
      icon: UserPlus,
      title: 'Elderly Care',
      description: 'Specialized nursing services for elderly patients, focusing on comfort, dignity, and quality of life.',
      details: [
        'Chronic disease management for conditions like diabetes, heart disease',
        'Fall prevention and mobility assistance',
        'Memory care for patients with dementia or Alzheimer\'s',
        'Nutritional guidance and meal planning',
        'Companionship and emotional support'
      ]
    },
    {
      icon: ShieldCheck,
      title: 'Pediatric Nursing',
      description: 'Compassionate care for children of all ages, addressing their unique healthcare requirements.',
      details: [
        'Specialized care for infants, children, and adolescents',
        'Management of chronic conditions and developmental disorders',
        'Post-surgical care and recovery support',
        'Medication administration and monitoring',
        'Family education and support'
      ]
    },
    {
      icon: Clock,
      title: '24/7 Emergency Care',
      description: 'Round-the-clock nursing services for emergency situations, ensuring immediate healthcare response.',
      details: [
        'Immediate response to medical emergencies',
        'Coordination with emergency medical services',
        'Stabilization and initial treatment',
        'Crisis management and intervention',
        'Continuous monitoring during critical situations'
      ]
    },
    {
      icon: Sparkles,
      title: 'Rehabilitation Support',
      description: 'Supporting patients through recovery and rehabilitation with specialized nursing techniques.',
      details: [
        'Post-surgical rehabilitation care',
        'Physical therapy coordination and support',
        'Progress monitoring and documentation',
        'Adaptive equipment training and assistance',
        'Rehabilitation exercise supervision'
      ]
    },
    {
      icon: Brain,
      title: 'Mental Health Nursing',
      description: 'Specialized care for patients with mental health conditions, focusing on holistic wellbeing.',
      details: [
        'Assessment and monitoring of mental health conditions',
        'Medication management for psychiatric disorders',
        'Crisis intervention and de-escalation techniques',
        'Therapeutic communication and emotional support',
        'Coordination with mental health professionals'
      ]
    },
    {
      icon: Thermometer,
      title: 'Wound Care Management',
      description: 'Expert care for wounds, including surgical sites, pressure ulcers, and diabetic wounds.',
      details: [
        'Specialized wound assessment and documentation',
        'Advanced dressing techniques and wound cleansing',
        'Infection prevention and management',
        'Pain management during wound care',
        'Patient and caregiver education on wound care'
      ]
    },
  ];
  
  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="relative py-16 bg-primary/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Our Services</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
              Comprehensive nursing solutions designed to provide exceptional care with compassion and expertise.
            </p>
          </motion.div>
        </div>
      </section>
      
      {/* Detailed Services Section */}
      <section className="section">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {detailedServices.map((service, index) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="card hover:shadow-xl"
              >
                <div className="flex items-start">
                  <div className="bg-primary/10 p-3 rounded-full mr-4">
                    <Icon size={24} className="text-primary" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-3">{service.title}</h3>
                    <p className="text-gray-600 mb-4">{service.description}</p>
                    <ul className="space-y-2">
                      {service.details.map((detail, idx) => (
                        <li key={idx} className="flex items-start">
                          <span className="text-primary mr-2">•</span>
                          <span>{detail}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </section>
      
      {/* Process Section */}
      <section className="py-16 bg-primary/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Care Process</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              We follow a comprehensive approach to ensure the highest quality of care for every patient.
            </p>
          </motion.div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              { number: '01', title: 'Assessment', description: 'Thorough evaluation of patient needs and health status' },
              { number: '02', title: 'Planning', description: 'Development of personalized care plans with clear objectives' },
              { number: '03', title: 'Implementation', description: 'Expert delivery of nursing care according to the care plan' },
              { number: '04', title: 'Evaluation', description: 'Continuous monitoring and adjustment of care as needed' },
            ].map((step, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.2 }}
                viewport={{ once: true }}
                className="card text-center"
              >
                <div className="inline-block bg-primary rounded-full w-12 h-12 flex items-center justify-center text-white font-bold mb-4">
                  {step.number}
                </div>
                <h3 className="text-xl font-bold mb-2">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Insurance Section */}
      <section className="section">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Insurance & Payment</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            We work with a variety of insurance providers to make our services accessible to all who need them.
          </p>
        </motion.div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            viewport={{ once: true }}
            className="card"
          >
            <h3 className="text-xl font-bold mb-4">Accepted Insurance Plans</h3>
            <p className="text-gray-600 mb-6">
              We accept a wide range of insurance plans to make our nursing services accessible and affordable.
              Our team will assist you in verifying your coverage and explaining any out-of-pocket expenses.
            </p>
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-gray-50 p-3 rounded-lg flex items-center justify-center">
                <span className="font-medium">Medicare</span>
              </div>
              <div className="bg-gray-50 p-3 rounded-lg flex items-center justify-center">
                <span className="font-medium">Medicaid</span>
              </div>
              <div className="bg-gray-50 p-3 rounded-lg flex items-center justify-center">
                <span className="font-medium">Blue Cross</span>
              </div>
              <div className="bg-gray-50 p-3 rounded-lg flex items-center justify-center">
                <span className="font-medium">Aetna</span>
              </div>
              <div className="bg-gray-50 p-3 rounded-lg flex items-center justify-center">
                <span className="font-medium">Cigna</span>
              </div>
              <div className="bg-gray-50 p-3 rounded-lg flex items-center justify-center">
                <span className="font-medium">United Healthcare</span>
              </div>
            </div>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            viewport={{ once: true }}
            className="card"
          >
            <h3 className="text-xl font-bold mb-4">Payment Options</h3>
            <p className="text-gray-600 mb-6">
              For services not covered by insurance or for patients without insurance, we offer
              several payment options to accommodate different financial situations.
            </p>
            <ul className="space-y-3">
              <li className="flex items-start">
                <span className="text-primary mr-2">•</span>
                <span>Flexible payment plans tailored to your financial situation</span>
              </li>
              <li className="flex items-start">
                <span className="text-primary mr-2">•</span>
                <span>Credit card payments (Visa, Mastercard, American Express, Discover)</span>
              </li>
              <li className="flex items-start">
                <span className="text-primary mr-2">•</span>
                <span>Health savings account (HSA) and flexible spending account (FSA)</span>
              </li>
              <li className="flex items-start">
                <span className="text-primary mr-2">•</span>
                <span>Sliding scale fees based on income eligibility</span>
              </li>
              <li className="flex items-start">
                <span className="text-primary mr-2">•</span>
                <span>Financial assistance programs for qualifying patients</span>
              </li>
            </ul>
          </motion.div>
        </div>
      </section>
      
      {/* Contact Section */}
      <ContactSection />
    </div>
  );
};

export default ServicesPage;