import React from 'react';
import { motion } from 'framer-motion';
import { Heart, Users, Clock, Sparkles, Phone, UserPlus, ShieldCheck, Coffee, Upload, Brain, Database, MessageSquare, Globe, Lock } from 'lucide-react';
import { Link } from 'react-router-dom';
import Hero from '../components/Hero';
import ServiceCard from '../components/ServiceCard';
import TestimonialCard from '../components/TestimonialCard';
import StatsSection from '../components/StatsSection';
import ContactSection from '../components/ContactSection';

const HomePage: React.FC = () => {
  // Timeline steps
  const timelineSteps = [
    {
      icon: Upload,
      title: 'Upload Patient Data',
      description: 'Securely upload patient information and symptoms through our intuitive interface.'
    },
    {
      icon: Brain,
      title: 'AI Analysis',
      description: 'Our advanced AI system analyzes medical records and research to provide insights.'
    },
    {
      icon: Database,
      title: 'Diagnosis Suggestions',
      description: 'Receive comprehensive diagnosis suggestions and personalized care pathways.'
    },
    {
      icon: MessageSquare,
      title: 'AI Collaboration',
      description: 'Work alongside your AI assistant to refine and implement treatment plans.'
    }
  ];

  // Product features
  const features = [
    {
      icon: MessageSquare,
      title: 'Real-time AI Consultation',
      description: 'Get instant medical insights and recommendations through our advanced AI system.'
    },
    {
      icon: Database,
      title: 'EHR Integration',
      description: 'Seamlessly integrate with existing Electronic Health Record systems.'
    },
    {
      icon: Globe,
      title: 'Multilingual Support',
      description: 'Break language barriers with our comprehensive multilingual symptom checker.'
    },
    {
      icon: UserPlus,
      title: 'Patient Portal',
      description: 'Access personalized health insights and AI-powered recommendations.'
    },
    {
      icon: Lock,
      title: 'Secure Collaboration',
      description: 'HIPAA-compliant platform for secure communication between healthcare providers.'
    }
  ];

  // Services data
  const services = [
    {
      icon: Heart,
      title: 'Home Healthcare',
      description: 'Professional nursing care in the comfort of your own home, tailored to your specific health needs.'
    },
    {
      icon: Users,
      title: 'Hospital Staffing',
      description: 'Providing qualified nursing professionals to hospitals and medical facilities to ensure quality patient care.'
    },
    {
      icon: UserPlus,
      title: 'Elderly Care',
      description: 'Specialized nursing services for elderly patients, focusing on comfort, dignity, and quality of life.'
    },
    {
      icon: ShieldCheck,
      title: 'Pediatric Nursing',
      description: 'Compassionate care for children of all ages, addressing their unique healthcare requirements.'
    },
    {
      icon: Clock,
      title: '24/7 Emergency Care',
      description: 'Round-the-clock nursing services for emergency situations, ensuring immediate healthcare response.'
    },
    {
      icon: Sparkles,
      title: 'Rehabilitation Support',
      description: 'Supporting patients through recovery and rehabilitation with specialized nursing techniques.'
    }
  ];
  
  // Testimonials data
  const testimonials = [
    {
      quote: "The nurses from FlorAlges provided exceptional care for my mother after her surgery. Their professionalism and compassion made a difficult time much easier for our family.",
      author: "Sarah Johnson",
      role: "Daughter of Patient",
      image: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    },
    {
      quote: "As a hospital administrator, I can confidently say that FlorAlges nurses are among the best. They integrate seamlessly with our staff and provide top-quality care.",
      author: "Dr. Michael Chen",
      role: "Hospital Director",
      image: "https://images.pexels.com/photos/5490276/pexels-photo-5490276.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    },
    {
      quote: "The pediatric nurse who cared for my son was incredible. She knew exactly how to make him comfortable and explained everything in a way that put us all at ease.",
      author: "James Wilson",
      role: "Parent",
      image: "https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    }
  ];
  
  return (
    <>
      <Hero />
      
      {/* How It Works Section */}
      <section className="py-16 bg-primary/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">How It Works</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Our AI-powered healthcare platform streamlines patient care through an innovative four-step process.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {timelineSteps.map((step, index) => {
              const Icon = step.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className="relative"
                >
                  <div className="card text-center h-full">
                    <div className="inline-block bg-primary/10 p-4 rounded-full mb-4">
                      <Icon size={24} className="text-primary" />
                    </div>
                    <h3 className="text-xl font-bold mb-2">{step.title}</h3>
                    <p className="text-gray-600">{step.description}</p>
                  </div>
                  {index < timelineSteps.length - 1 && (
                    <div className="hidden lg:block absolute top-1/2 right-0 w-full h-[2px] bg-primary/20 transform translate-x-1/2">
                      <div className="absolute right-0 top-1/2 transform translate-x-1/2 -translate-y-1/2 w-3 h-3 bg-primary rounded-full" />
                    </div>
                  )}
                </motion.div>
              );
            })}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.5 }}
            viewport={{ once: true }}
            className="text-center mt-12"
          >
            <Link to="/patient-profile" className="btn-primary inline-flex items-center">
              Try Demo Now
              <Sparkles className="ml-2 h-5 w-5" />
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Product Features Section */}
      <section className="section">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Product Features</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Discover how our AI-powered platform revolutionizes healthcare delivery.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="card hover:shadow-xl"
              >
                <div className="inline-block bg-primary/10 p-4 rounded-full mb-4">
                  <Icon size={24} className="text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </motion.div>
            );
          })}
        </div>
      </section>
      
      {/* Services Section */}
      <section className="section">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
        >
          <h2 className="section-title">Our Services</h2>
          <p className="text-center text-gray-600 mb-12 max-w-3xl mx-auto">
            We offer a comprehensive range of nursing services designed to meet the diverse
            healthcare needs of our patients with compassion and expertise.
          </p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <ServiceCard
              key={index}
              icon={service.icon}
              title={service.title}
              description={service.description}
              delay={index * 0.1}
            />
          ))}
        </div>
      </section>
      
      {/* Why Choose Us Section */}
      <section className="py-16 bg-primary/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Choose FlorAlges Nursing?</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              We combine professional expertise with a personal touch to deliver exceptional nursing care.
            </p>
          </motion.div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              viewport={{ once: true }}
              className="bg-white rounded-xl shadow-lg overflow-hidden"
            >
              <img 
                src="https://images.pexels.com/photos/7089401/pexels-photo-7089401.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Nursing Professional" 
                className="w-full h-64 object-cover"
              />
              <div className="p-6">
                <h3 className="text-2xl font-bold mb-4">Our Commitment</h3>
                <p className="text-gray-600 mb-6">
                  At FlorAlges Nursing, we are committed to delivering the highest standard of care with integrity, 
                  compassion, and professionalism. Our mission is to enhance the quality of life for our patients 
                  through personalized nursing services.
                </p>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <div className="bg-primary/10 p-1 rounded-full mr-3 mt-1">
                      <Heart size={16} className="text-primary" />
                    </div>
                    <span>Patient-centered care approach</span>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-primary/10 p-1 rounded-full mr-3 mt-1">
                      <ShieldCheck size={16} className="text-primary" />
                    </div>
                    <span>Rigorous quality standards</span>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-primary/10 p-1 rounded-full mr-3 mt-1">
                      <Users size={16} className="text-primary" />
                    </div>
                    <span>Collaborative care teams</span>
                  </li>
                </ul>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              viewport={{ once: true }}
              className="bg-white rounded-xl shadow-lg overflow-hidden"
            >
              <img 
                src="https://images.pexels.com/photos/3985163/pexels-photo-3985163.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Nursing Team" 
                className="w-full h-64 object-cover"
              />
              <div className="p-6">
                <h3 className="text-2xl font-bold mb-4">Our Team</h3>
                <p className="text-gray-600 mb-6">
                  Our team consists of highly qualified nursing professionals who are not only experts in 
                  their field but also deeply committed to providing compassionate care. We believe in 
                  building relationships based on trust and understanding.
                </p>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <div className="bg-primary/10 p-1 rounded-full mr-3 mt-1">
                      <Sparkles size={16} className="text-primary" />
                    </div>
                    <span>Certified and experienced nurses</span>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-primary/10 p-1 rounded-full mr-3 mt-1">
                      <Coffee size={16} className="text-primary" />
                    </div>
                    <span>Continuous education and training</span>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-primary/10 p-1 rounded-full mr-3 mt-1">
                      <Phone size={16} className="text-primary" />
                    </div>
                    <span>24/7 availability</span>
                  </li>
                </ul>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Stats Section */}
      <StatsSection />
      
      {/* Testimonials Section */}
      <section className="section">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
        >
          <h2 className="section-title">What Our Clients Say</h2>
          <p className="text-center text-gray-600 mb-12 max-w-3xl mx-auto">
            Don't just take our word for it. Here's what our clients have to say about our nursing services.
          </p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <TestimonialCard
              key={index}
              quote={testimonial.quote}
              author={testimonial.author}
              role={testimonial.role}
              image={testimonial.image}
              delay={index * 0.2}
            />
          ))}
        </div>
      </section>
      
      {/* Contact Section */}
      <ContactSection />
    </>
  );
};

export default HomePage;
<script>
(function(){if(!window.chatbase||window.chatbase("getState")!=="initialized"){window.chatbase=(...arguments)=>{if(!window.chatbase.q){window.chatbase.q=[]}window.chatbase.q.push(arguments)};window.chatbase=new Proxy(window.chatbase,{get(target,prop){if(prop==="q"){return target.q}return(...args)=>target(prop,...args)}})}const onLoad=function(){const script=document.createElement("script");script.src="https://www.chatbase.co/embed.min.js";script.id="L7Me9g8Ly33kh8b09r3VN";script.domain="www.chatbase.co";document.body.appendChild(script)};if(document.readyState==="complete"){onLoad()}else{window.addEventListener("load",onLoad)}})();
</script>