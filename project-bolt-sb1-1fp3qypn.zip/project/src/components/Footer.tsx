import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, Phone, Mail, MapPin, Facebook, Instagram, Twitter } from 'lucide-react';
import Logo from './Logo';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-800 text-white pt-12 pb-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Company Info */}
          <div>
            <div className="flex items-center mb-4">
              <Logo className="h-10 w-10" />
              <span className="ml-2 text-xl font-bold">FlorAlges_Nursing</span>
            </div>
            <p className="mb-4 text-gray-300">Born in code, tested with care.</p>
            <p className="text-gray-300 flex items-start mb-2">
              <MapPin size={18} className="mr-2 flex-shrink-0 mt-1" />
              <span>123 Healthcare Avenue, Medical District, FL 12345</span>
            </p>
            <p className="text-gray-300 flex items-center mb-2">
              <Phone size={18} className="mr-2" />
              <span>(123) 456-7890</span>
            </p>
            <p className="text-gray-300 flex items-center">
              <Mail size={18} className="mr-2" />
              <span>info@floralgesnursing.com</span>
            </p>
          </div>
          
          {/* Services */}
          <div>
            <h3 className="text-lg font-bold mb-4 border-b border-gray-700 pb-2">Our Services</h3>
            <ul className="space-y-2">
              <li><Link to="/services" className="text-gray-300 hover:text-white">Home Care</Link></li>
              <li><Link to="/services" className="text-gray-300 hover:text-white">Hospital Staffing</Link></li>
              <li><Link to="/services" className="text-gray-300 hover:text-white">Elderly Care</Link></li>
              <li><Link to="/services" className="text-gray-300 hover:text-white">Pediatric Nursing</Link></li>
              <li><Link to="/services" className="text-gray-300 hover:text-white">Rehabilitation Support</Link></li>
              <li><Link to="/services" className="text-gray-300 hover:text-white">Mental Health Nursing</Link></li>
            </ul>
          </div>
          
          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-bold mb-4 border-b border-gray-700 pb-2">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link to="/" className="text-gray-300 hover:text-white">Home</Link></li>
              <li><Link to="/about" className="text-gray-300 hover:text-white">About Us</Link></li>
              <li><Link to="/services" className="text-gray-300 hover:text-white">Services</Link></li>
              <li><Link to="/contact" className="text-gray-300 hover:text-white">Contact</Link></li>
              <li><Link to="/about" className="text-gray-300 hover:text-white">Our Team</Link></li>
              <li><Link to="/about" className="text-gray-300 hover:text-white">Testimonials</Link></li>
            </ul>
          </div>
          
          {/* Newsletter */}
          <div>
            <h3 className="text-lg font-bold mb-4 border-b border-gray-700 pb-2">Stay Connected</h3>
            <p className="text-gray-300 mb-4">Subscribe to our newsletter for healthcare tips and updates.</p>
            <form className="mb-4">
              <div className="flex flex-col sm:flex-row gap-2">
                <input
                  type="email"
                  placeholder="Your Email"
                  className="px-4 py-2 rounded-lg focus:outline-none text-gray-800 flex-grow"
                />
                <button 
                  type="submit" 
                  className="bg-primary hover:bg-primary/90 px-4 py-2 rounded-lg transition-colors"
                >
                  Subscribe
                </button>
              </div>
            </form>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-300 hover:text-white">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-gray-300 hover:text-white">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-gray-300 hover:text-white">
                <Twitter size={20} />
              </a>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-8 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm">
            &copy; {new Date().getFullYear()} FlorAlges Nursing. All rights reserved.
          </p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <Link to="/privacy" className="text-gray-400 hover:text-white text-sm">Privacy Policy</Link>
            <Link to="/terms" className="text-gray-400 hover:text-white text-sm">Terms of Service</Link>
            <Link to="/sitemap" className="text-gray-400 hover:text-white text-sm">Sitemap</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;