import React from 'react';
import { ChevronRight, Fingerprint, Lock } from 'lucide-react';
import BiometricScanner from '../components/biometrics/BiometricScanner';

const Biometrics: React.FC = () => {
  return (
    <div className="pt-28 pb-16 container mx-auto px-4">
      <div className="mb-12">
        <div>
          <h1 className="text-3xl font-bold mb-2">Biometric Authentication</h1>
          <p className="text-gray-600 max-w-3xl">
            Secure access to patient data with advanced biometric authentication methods.
          </p>
        </div>
        
        <div className="mt-6 flex items-center text-sm">
          <a href="/" className="text-gray-500 hover:text-[#457B9D]">Home</a>
          <ChevronRight size={14} className="mx-2 text-gray-400" />
          <span className="text-[#457B9D]">Biometrics</span>
        </div>
      </div>
      
      {/* Biometric Scanner Component */}
      <BiometricScanner />
      
      {/* Additional Information */}
      <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="p-6 border-b border-gray-100">
            <h2 className="text-2xl font-bold flex items-center">
              <Fingerprint className="mr-2 text-[#E63946]" size={24} />
              Biometric Security
            </h2>
          </div>
          <div className="p-6">
            <p className="text-gray-600 mb-6">
              Biometric authentication provides a higher level of security than traditional password-based methods.
              Our system uses state-of-the-art technology to ensure that only authorized personnel can access sensitive patient data.
            </p>
            
            <h3 className="font-medium text-gray-800 mb-3">Key Benefits:</h3>
            <ul className="space-y-2 mb-6">
              <li className="flex items-start">
                <div className="h-5 w-5 rounded-full bg-green-100 text-green-600 flex items-center justify-center mt-0.5 mr-3">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                </div>
                <span className="text-gray-700">Enhanced security compared to passwords</span>
              </li>
              <li className="flex items-start">
                <div className="h-5 w-5 rounded-full bg-green-100 text-green-600 flex items-center justify-center mt-0.5 mr-3">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                </div>
                <span className="text-gray-700">Cannot be forgotten or lost like passwords</span>
              </li>
              <li className="flex items-start">
                <div className="h-5 w-5 rounded-full bg-green-100 text-green-600 flex items-center justify-center mt-0.5 mr-3">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                </div>
                <span className="text-gray-700">Difficult to forge or replicate</span>
              </li>
              <li className="flex items-start">
                <div className="h-5 w-5 rounded-full bg-green-100 text-green-600 flex items-center justify-center mt-0.5 mr-3">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                </div>
                <span className="text-gray-700">Creates detailed audit trails for compliance</span>
              </li>
            </ul>
            
            <h3 className="font-medium text-gray-800 mb-3">Supported Biometric Methods:</h3>
            <ul className="grid grid-cols-2 gap-4">
              <li className="flex items-center p-3 bg-gray-50 rounded-lg">
                <Fingerprint size={20} className="text-[#457B9D] mr-2" />
                <span>Fingerprint Scanning</span>
              </li>
              <li className="flex items-center p-3 bg-gray-50 rounded-lg">
                <Fingerprint size={20} className="text-[#457B9D] mr-2" />
                <span>Facial Recognition</span>
              </li>
              <li className="flex items-center p-3 bg-gray-50 rounded-lg">
                <Fingerprint size={20} className="text-[#457B9D] mr-2" />
                <span>Voice Authentication</span>
              </li>
              <li className="flex items-center p-3 bg-gray-50 rounded-lg">
                <Fingerprint size={20} className="text-[#457B9D] mr-2" />
                <span>Retina Scanning</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="p-6 border-b border-gray-100">
            <h2 className="text-2xl font-bold flex items-center">
              <Lock className="mr-2 text-[#E63946]" size={24} />
              Privacy & Implementation
            </h2>
          </div>
          <div className="p-6">
            <p className="text-gray-600 mb-6">
              While biometric authentication provides enhanced security, it's important to implement it properly to ensure privacy and compliance with regulations.
            </p>
            
            <h3 className="font-medium text-gray-800 mb-3">Privacy Considerations:</h3>
            <ul className="space-y-4 mb-6">
              <li className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-medium text-blue-800 mb-1">Secure Storage</h4>
                <p className="text-sm text-blue-700">
                  Biometric templates are encrypted and stored securely, never as raw biometric data.
                </p>
              </li>
              <li className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-medium text-blue-800 mb-1">Consent</h4>
                <p className="text-sm text-blue-700">
                  Clear user consent is obtained before collecting and processing any biometric data.
                </p>
              </li>
              <li className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-medium text-blue-800 mb-1">Limited Retention</h4>
                <p className="text-sm text-blue-700">
                  Biometric data is only retained for as long as necessary for authentication purposes.
                </p>
              </li>
            </ul>
            
            <h3 className="font-medium text-gray-800 mb-3">Implementation Guide:</h3>
            <ol className="space-y-2 list-decimal list-inside text-gray-700">
              <li>Determine which biometric methods are appropriate for your use case</li>
              <li>Implement secure storage and encryption for biometric templates</li>
              <li>Establish clear consent mechanisms before enrollment</li>
              <li>Create fallback authentication methods for when biometrics fail</li>
              <li>Ensure compliance with relevant privacy regulations (HIPAA, GDPR)</li>
              <li>Regularly audit and test the security of your biometric system</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Biometrics;