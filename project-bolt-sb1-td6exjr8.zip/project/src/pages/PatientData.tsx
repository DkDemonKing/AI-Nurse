import React from 'react';
import { FileText, ChevronRight } from 'lucide-react';
import PatientGenerator from '../components/patient-data/PatientGenerator';

const PatientData: React.FC = () => {
  return (
    <div className="pt-28 pb-16 container mx-auto px-4">
      <div className="mb-12">
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div>
            <h1 className="text-3xl font-bold mb-2">Synthetic Patient Data Generation</h1>
            <p className="text-gray-600 max-w-3xl">
              Create realistic, HIPAA-compliant patient profiles for healthcare application testing and development.
            </p>
          </div>
          
          <button className="bg-[#E63946] text-white px-4 py-2 rounded-md flex items-center hover:bg-opacity-90 transition-colors">
            <FileText size={18} className="mr-2" />
            Export All Data
          </button>
        </div>
        
        <div className="mt-6 flex items-center text-sm">
          <a href="/" className="text-gray-500 hover:text-[#457B9D]">Home</a>
          <ChevronRight size={14} className="mx-2 text-gray-400" />
          <span className="text-[#457B9D]">Patient Data</span>
        </div>
      </div>
      
      <div className="mb-8">
        <PatientGenerator />
      </div>
      
      <div className="mt-16 bg-white rounded-lg shadow-md p-6">
        <h2 className="text-2xl font-bold mb-4">Advanced Options</h2>
        <p className="text-gray-600 mb-6">
          In a full implementation, this section would allow you to:
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="border border-gray-200 rounded-lg p-5">
            <h3 className="font-bold text-lg mb-3">Batch Generation</h3>
            <p className="text-gray-600 mb-4">
              Generate multiple patient profiles at once with customizable parameters.
            </p>
            <button className="text-[#457B9D] hover:text-[#E63946] font-medium flex items-center transition-colors">
              Configure Batch
              <ChevronRight size={16} className="ml-1" />
            </button>
          </div>
          
          <div className="border border-gray-200 rounded-lg p-5">
            <h3 className="font-bold text-lg mb-3">Custom Templates</h3>
            <p className="text-gray-600 mb-4">
              Create and save templates for specific medical scenarios or patient types.
            </p>
            <button className="text-[#457B9D] hover:text-[#E63946] font-medium flex items-center transition-colors">
              Manage Templates
              <ChevronRight size={16} className="ml-1" />
            </button>
          </div>
          
          <div className="border border-gray-200 rounded-lg p-5">
            <h3 className="font-bold text-lg mb-3">Data Export</h3>
            <p className="text-gray-600 mb-4">
              Export data in various formats including JSON, CSV, and FHIR.
            </p>
            <button className="text-[#457B9D] hover:text-[#E63946] font-medium flex items-center transition-colors">
              Export Options
              <ChevronRight size={16} className="ml-1" />
            </button>
          </div>
          
          <div className="border border-gray-200 rounded-lg p-5">
            <h3 className="font-bold text-lg mb-3">API Access</h3>
            <p className="text-gray-600 mb-4">
              Access our data generation capabilities through a RESTful API.
            </p>
            <button className="text-[#457B9D] hover:text-[#E63946] font-medium flex items-center transition-colors">
              API Documentation
              <ChevronRight size={16} className="ml-1" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PatientData;