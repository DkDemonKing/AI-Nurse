import React from 'react';
import Hero from '../components/home/Hero';
import Features from '../components/home/Features';
import DataGeneration from '../components/home/DataGeneration';

const Home: React.FC = () => {
  return (
    <div>
      <Hero />
      <Features />
      <DataGeneration />
      
      {/* Call to Action Section */}
      <section className="py-20 bg-gradient-to-r from-[#457B9D] to-[#2DD3BF]">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">Ready to Transform Your Healthcare Testing?</h2>
          <p className="text-white text-lg mb-8 max-w-2xl mx-auto">
            Start generating synthetic patient data that's HIPAA and GDPR compliant today.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <a href="/patient-data" className="bg-white text-[#457B9D] px-8 py-3 rounded-md font-medium hover:bg-gray-100 transition-colors">
              Get Started
            </a>
            <a href="/documentation" className="bg-transparent border-2 border-white text-white px-8 py-3 rounded-md font-medium hover:bg-white hover:bg-opacity-10 transition-colors">
              Learn More
            </a>
          </div>
        </div>
      </section>
      
      {/* Testimonials Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Trusted by Healthcare Professionals</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              See what healthcare organizations are saying about our platform.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow">
              <div className="flex items-center mb-4">
                <div className="text-yellow-400 flex">
                  {'★★★★★'.split('').map((_, i) => (
                    <span key={i}>★</span>
                  ))}
                </div>
              </div>
              <p className="text-gray-600 mb-6">
                "FlorAIges_Medizone has revolutionized how we test our healthcare applications. The synthetic data is incredibly realistic and allows us to thoroughly test edge cases."
              </p>
              <div>
                <p className="font-semibold">Dr. Sarah Johnson</p>
                <p className="text-sm text-gray-500">Chief Medical Information Officer</p>
              </div>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow">
              <div className="flex items-center mb-4">
                <div className="text-yellow-400 flex">
                  {'★★★★★'.split('').map((_, i) => (
                    <span key={i}>★</span>
                  ))}
                </div>
              </div>
              <p className="text-gray-600 mb-6">
                "The compliance features have saved us countless hours of manual verification. We can now be confident that our data handling meets all regulatory requirements."
              </p>
              <div>
                <p className="font-semibold">Michael Chen</p>
                <p className="text-sm text-gray-500">Compliance Director, HealthTech Inc.</p>
              </div>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow">
              <div className="flex items-center mb-4">
                <div className="text-yellow-400 flex">
                  {'★★★★'.split('').map((_, i) => (
                    <span key={i}>★</span>
                  ))}
                </div>
              </div>
              <p className="text-gray-600 mb-6">
                "The hospital finder feature has been a game-changer for our patients. They can now easily find facilities that accept their insurance and compare costs."
              </p>
              <div>
                <p className="font-semibold">Lisa Rodriguez</p>
                <p className="text-sm text-gray-500">Patient Advocate</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;