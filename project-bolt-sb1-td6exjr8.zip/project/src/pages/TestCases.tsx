import React from 'react';
import { FileText, ChevronRight, Plus, Code, CheckCircle } from 'lucide-react';
import Card, { CardContent, CardHeader } from '../components/ui/Card';
import Button from '../components/ui/Button';
import Badge from '../components/ui/Badge';
import { TestCase } from '../types';

// Sample test cases
const testCases: TestCase[] = [
  {
    id: "tc1",
    name: "Patient Registration Flow",
    description: "Tests the complete patient registration process including form validation, data persistence, and confirmation emails.",
    steps: [
      "Navigate to registration page",
      "Fill out patient information form",
      "Submit registration",
      "Verify confirmation page",
      "Check database for correct patient record",
      "Verify email notification sent"
    ],
    expectedResults: [
      "Form validates all required fields",
      "Registration completes successfully",
      "Patient record created in database",
      "Confirmation email received"
    ],
    category: "registration",
    createdAt: new Date().toISOString()
  },
  {
    id: "tc2",
    name: "Appointment Scheduling",
    description: "Tests the appointment scheduling flow, including calendar integration, time slot selection, and provider availability.",
    steps: [
      "Log in as patient",
      "Navigate to scheduling page",
      "Select doctor and service",
      "Choose available time slot",
      "Confirm appointment",
      "Verify appointment in calendar"
    ],
    expectedResults: [
      "Available time slots displayed correctly",
      "Appointment booked successfully",
      "Confirmation notification sent",
      "Appointment appears in calendar"
    ],
    category: "appointments",
    createdAt: new Date().toISOString()
  },
  {
    id: "tc3",
    name: "Medical Record Access",
    description: "Tests the secure access controls for medical records, ensuring only authorized personnel can view patient data.",
    steps: [
      "Log in as doctor",
      "Search for patient",
      "Request medical record access",
      "View complete medical history",
      "Log out and log in as nurse",
      "Attempt to access same record"
    ],
    expectedResults: [
      "Doctor can access complete medical record",
      "Nurse has limited access based on role",
      "All access attempts are logged for audit",
      "Unauthorized access attempts are blocked"
    ],
    category: "security",
    createdAt: new Date().toISOString()
  }
];

const TestCases: React.FC = () => {
  return (
    <div className="pt-28 pb-16 container mx-auto px-4">
      <div className="mb-12">
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div>
            <h1 className="text-3xl font-bold mb-2">Automated Test Case Creation</h1>
            <p className="text-gray-600 max-w-3xl">
              Develop functional test scripts and edge cases specifically designed for healthcare applications.
            </p>
          </div>
          
          <Button icon={<Plus size={18} />}>
            Create New Test Case
          </Button>
        </div>
        
        <div className="mt-6 flex items-center text-sm">
          <a href="/" className="text-gray-500 hover:text-[#457B9D]">Home</a>
          <ChevronRight size={14} className="mx-2 text-gray-400" />
          <span className="text-[#457B9D]">Test Cases</span>
        </div>
      </div>
      
      {/* Test case filters */}
      <div className="mb-8 bg-white rounded-lg shadow p-4">
        <div className="flex flex-wrap items-center gap-4">
          <div>
            <label className="block text-sm text-gray-600 mb-1">Category</label>
            <select className="border border-gray-300 rounded-md px-3 py-2 bg-white text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#457B9D]">
              <option value="">All Categories</option>
              <option value="registration">Registration</option>
              <option value="appointments">Appointments</option>
              <option value="security">Security</option>
              <option value="billing">Billing</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm text-gray-600 mb-1">Status</label>
            <select className="border border-gray-300 rounded-md px-3 py-2 bg-white text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#457B9D]">
              <option value="">All Statuses</option>
              <option value="active">Active</option>
              <option value="draft">Draft</option>
              <option value="archived">Archived</option>
            </select>
          </div>
          
          <div className="ml-auto">
            <label className="block text-sm text-gray-600 mb-1">Search</label>
            <input 
              type="text" 
              placeholder="Search test cases..." 
              className="border border-gray-300 rounded-md px-3 py-2 bg-white text-gray-700 focus:outline-none focus:ring-2 focus:ring-[#457B9D]"
            />
          </div>
        </div>
      </div>
      
      {/* Test cases list */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {testCases.map((testCase) => (
          <TestCaseCard key={testCase.id} testCase={testCase} />
        ))}
      </div>
      
      {/* Test automation section */}
      <div className="bg-white rounded-lg shadow-md overflow-hidden mt-12">
        <div className="p-6 border-b border-gray-100">
          <h2 className="text-2xl font-bold">Test Automation Integration</h2>
          <p className="text-gray-600 mt-2">
            Connect your test cases to automated testing frameworks
          </p>
        </div>
        
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <IntegrationCard 
              title="Selenium WebDriver" 
              description="Generate Selenium test scripts for web application testing"
              icon={<Code size={24} />}
              connected={true}
            />
            
            <IntegrationCard 
              title="Appium" 
              description="Create mobile application tests for iOS and Android"
              icon={<Code size={24} />}
              connected={false}
            />
            
            <IntegrationCard 
              title="Cypress" 
              description="End-to-end testing for modern web applications"
              icon={<Code size={24} />}
              connected={false}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

interface TestCaseCardProps {
  testCase: TestCase;
}

const TestCaseCard: React.FC<TestCaseCardProps> = ({ testCase }) => {
  return (
    <Card className="h-full">
      <CardHeader
        title={testCase.name}
        subtitle={new Date(testCase.createdAt).toLocaleDateString()}
        action={
          <Badge 
            variant={
              testCase.category === 'security' ? 'danger' : 
              testCase.category === 'registration' ? 'primary' : 
              'secondary'
            }
          >
            {testCase.category}
          </Badge>
        }
      />
      <CardContent>
        <p className="text-gray-600 mb-4">{testCase.description}</p>
        
        <div className="mb-4">
          <h4 className="font-medium text-gray-800 mb-2">Test Steps</h4>
          <ol className="list-decimal list-inside text-gray-600 space-y-1">
            {testCase.steps.slice(0, 3).map((step, idx) => (
              <li key={idx}>{step}</li>
            ))}
            {testCase.steps.length > 3 && (
              <li className="text-gray-400">
                + {testCase.steps.length - 3} more steps
              </li>
            )}
          </ol>
        </div>
        
        <div className="mb-4">
          <h4 className="font-medium text-gray-800 mb-2">Expected Results</h4>
          <ul className="space-y-1">
            {testCase.expectedResults.slice(0, 2).map((result, idx) => (
              <li key={idx} className="flex items-start">
                <CheckCircle size={16} className="text-green-500 mt-1 mr-2 flex-shrink-0" />
                <span className="text-gray-600">{result}</span>
              </li>
            ))}
            {testCase.expectedResults.length > 2 && (
              <li className="text-gray-400 pl-6">
                + {testCase.expectedResults.length - 2} more expected results
              </li>
            )}
          </ul>
        </div>
        
        <div className="flex space-x-3">
          <Button variant="outline" size="sm">View Details</Button>
          <Button variant="outline" size="sm">Run Test</Button>
        </div>
      </CardContent>
    </Card>
  );
};

interface IntegrationCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  connected: boolean;
}

const IntegrationCard: React.FC<IntegrationCardProps> = ({ 
  title, 
  description, 
  icon,
  connected 
}) => {
  return (
    <div className="border border-gray-200 rounded-lg p-5">
      <div className="flex items-start">
        <div className="h-10 w-10 rounded-md bg-[#457B9D] bg-opacity-10 text-[#457B9D] flex items-center justify-center mr-4">
          {icon}
        </div>
        <div>
          <h3 className="font-bold text-lg mb-1">{title}</h3>
          <p className="text-gray-600 text-sm mb-4">{description}</p>
          
          {connected ? (
            <div className="flex items-center">
              <CheckCircle size={16} className="text-green-500 mr-2" />
              <span className="text-green-600 text-sm font-medium">Connected</span>
            </div>
          ) : (
            <Button size="sm" variant="outline">Connect</Button>
          )}
        </div>
      </div>
    </div>
  );
};

export default TestCases;