import React from 'react';
import { CheckCircle, ChevronRight, AlertCircle, Shield, Lock, FileCheck } from 'lucide-react';
import Card, { CardContent, CardHeader } from '../components/ui/Card';
import Button from '../components/ui/Button';

const Compliance: React.FC = () => {
  return (
    <div className="pt-28 pb-16 container mx-auto px-4">
      <div className="mb-12">
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div>
            <h1 className="text-3xl font-bold mb-2">Privacy Compliance</h1>
            <p className="text-gray-600 max-w-3xl">
              Ensure all generated data is HIPAA and GDPR compliant while maintaining realistic medical scenarios.
            </p>
          </div>
          
          <Button icon={<FileCheck size={18} />}>
            Generate Compliance Report
          </Button>
        </div>
        
        <div className="mt-6 flex items-center text-sm">
          <a href="/" className="text-gray-500 hover:text-[#457B9D]">Home</a>
          <ChevronRight size={14} className="mx-2 text-gray-400" />
          <span className="text-[#457B9D]">Compliance</span>
        </div>
      </div>
      
      {/* Compliance Status */}
      <div className="bg-white rounded-lg shadow-md overflow-hidden mb-8">
        <div className="p-6 border-b border-gray-100">
          <h2 className="text-2xl font-bold">Compliance Status</h2>
          <p className="text-gray-600 mt-2">
            Current compliance status of your synthetic data
          </p>
        </div>
        
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <ComplianceCard 
              title="HIPAA Compliance" 
              status="compliant"
              description="Your synthetic data generation is fully HIPAA compliant. All PHI is properly de-identified."
              lastChecked="2 hours ago"
              icon={<Shield size={24} />}
            />
            
            <ComplianceCard 
              title="GDPR Compliance" 
              status="compliant"
              description="Your data processing activities comply with GDPR requirements for synthetic data."
              lastChecked="2 hours ago"
              icon={<Lock size={24} />}
            />
          </div>
        </div>
        
        <div className="bg-gray-50 p-6 border-t border-gray-100">
          <h3 className="font-medium text-gray-800 mb-4">Monthly Compliance Audit Results</h3>
          <div className="h-12 bg-gray-200 rounded-full overflow-hidden">
            <div className="h-full bg-green-500 rounded-full" style={{ width: '95%' }}></div>
          </div>
          <div className="flex justify-between mt-2 text-sm">
            <span className="text-gray-600">95% Compliance Score</span>
            <span className="text-green-600 font-medium">Excellent</span>
          </div>
        </div>
      </div>
      
      {/* Compliance Features */}
      <div className="mb-12">
        <h2 className="text-2xl font-bold mb-6">Compliance Features</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <FeatureCard 
            title="Automated De-identification" 
            description="Automatically removes or transforms protected health information (PHI) to ensure compliance with privacy regulations."
            icon={<Shield size={24} />}
          />
          
          <FeatureCard 
            title="Audit Trails" 
            description="Comprehensive logs of all data generation and access activities for compliance verification and reporting."
            icon={<FileCheck size={24} />}
          />
          
          <FeatureCard 
            title="Data Minimization" 
            description="Generates only the minimum necessary data required for your specific testing or development needs."
            icon={<Lock size={24} />}
          />
        </div>
      </div>
      
      {/* Compliance Checklist */}
      <div className="bg-white rounded-lg shadow-md overflow-hidden mb-8">
        <div className="p-6 border-b border-gray-100">
          <h2 className="text-2xl font-bold">Compliance Checklist</h2>
          <p className="text-gray-600 mt-2">
            Key compliance requirements and their status
          </p>
        </div>
        
        <div className="p-6">
          <div className="space-y-4">
            <ChecklistItem 
              title="Patient Identifiers Removed" 
              description="Names, addresses, phone numbers, and other direct identifiers are removed or replaced with synthetic data."
              status="complete"
            />
            
            <ChecklistItem 
              title="Data Encryption" 
              description="All data is encrypted both in transit and at rest using industry-standard encryption protocols."
              status="complete"
            />
            
            <ChecklistItem 
              title="Access Controls" 
              description="Role-based access controls ensure that only authorized users can access specific types of data."
              status="complete"
            />
            
            <ChecklistItem 
              title="Data Processing Agreement" 
              description="A signed DPA is required for full GDPR compliance when processing data on behalf of clients."
              status="warning"
            />
            
            <ChecklistItem 
              title="Breach Notification Procedure" 
              description="A documented process for notifying affected parties in the event of a data breach."
              status="complete"
            />
          </div>
        </div>
      </div>
      
      {/* Compliance Resources */}
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="p-6 border-b border-gray-100">
          <h2 className="text-2xl font-bold">Compliance Resources</h2>
          <p className="text-gray-600 mt-2">
            Helpful resources for maintaining compliance
          </p>
        </div>
        
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <ResourceCard 
              title="HIPAA Compliance Guide" 
              description="A comprehensive guide to HIPAA compliance requirements for synthetic healthcare data."
              link="#"
            />
            
            <ResourceCard 
              title="GDPR for Healthcare Data" 
              description="Understanding the GDPR requirements specific to healthcare data processing."
              link="#"
            />
            
            <ResourceCard 
              title="De-identification Best Practices" 
              description="Best practices for de-identifying protected health information while maintaining data utility."
              link="#"
            />
            
            <ResourceCard 
              title="Compliance Certification Process" 
              description="Steps to certify your data generation processes for regulatory compliance."
              link="#"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

interface ComplianceCardProps {
  title: string;
  status: 'compliant' | 'non-compliant' | 'warning';
  description: string;
  lastChecked: string;
  icon: React.ReactNode;
}

const ComplianceCard: React.FC<ComplianceCardProps> = ({ 
  title, 
  status, 
  description, 
  lastChecked,
  icon
}) => {
  return (
    <Card className="h-full">
      <CardHeader
        title={title}
        icon={icon}
      />
      <CardContent>
        <div className="flex items-center mb-4">
          {status === 'compliant' ? (
            <div className="flex items-center text-green-600">
              <CheckCircle size={20} className="mr-2" />
              <span className="font-medium">Compliant</span>
            </div>
          ) : status === 'warning' ? (
            <div className="flex items-center text-yellow-600">
              <AlertCircle size={20} className="mr-2" />
              <span className="font-medium">Needs Attention</span>
            </div>
          ) : (
            <div className="flex items-center text-red-600">
              <AlertCircle size={20} className="mr-2" />
              <span className="font-medium">Non-Compliant</span>
            </div>
          )}
        </div>
        
        <p className="text-gray-600 mb-4">{description}</p>
        
        <div className="text-sm text-gray-500">
          Last checked: {lastChecked}
        </div>
      </CardContent>
    </Card>
  );
};

interface FeatureCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ title, description, icon }) => {
  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="h-12 w-12 rounded-md bg-[#457B9D] bg-opacity-10 text-[#457B9D] flex items-center justify-center mb-4">
        {icon}
      </div>
      <h3 className="text-lg font-bold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
};

interface ChecklistItemProps {
  title: string;
  description: string;
  status: 'complete' | 'incomplete' | 'warning';
}

const ChecklistItem: React.FC<ChecklistItemProps> = ({ title, description, status }) => {
  return (
    <div className="flex border-b border-gray-100 pb-4">
      <div className="mr-4 mt-1">
        {status === 'complete' ? (
          <div className="h-6 w-6 rounded-full bg-green-100 text-green-600 flex items-center justify-center">
            <CheckCircle size={16} />
          </div>
        ) : status === 'warning' ? (
          <div className="h-6 w-6 rounded-full bg-yellow-100 text-yellow-600 flex items-center justify-center">
            <AlertCircle size={16} />
          </div>
        ) : (
          <div className="h-6 w-6 rounded-full bg-gray-100 text-gray-400 flex items-center justify-center">
            <CheckCircle size={16} />
          </div>
        )}
      </div>
      <div>
        <h3 className="font-medium text-gray-800 mb-1">{title}</h3>
        <p className="text-sm text-gray-600">{description}</p>
      </div>
    </div>
  );
};

interface ResourceCardProps {
  title: string;
  description: string;
  link: string;
}

const ResourceCard: React.FC<ResourceCardProps> = ({ title, description, link }) => {
  return (
    <div className="border border-gray-200 rounded-lg p-5">
      <h3 className="font-bold text-lg mb-2">{title}</h3>
      <p className="text-gray-600 text-sm mb-4">{description}</p>
      <a 
        href={link} 
        className="text-[#457B9D] hover:text-[#E63946] font-medium flex items-center transition-colors"
      >
        View Resource
        <ChevronRight size={16} className="ml-1" />
      </a>
    </div>
  );
};

export default Compliance;