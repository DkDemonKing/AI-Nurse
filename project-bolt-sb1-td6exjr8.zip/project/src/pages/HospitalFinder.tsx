import React from 'react';
import { ChevronRight, MapPin } from 'lucide-react';
import MapComponent from '../components/hospital-finder/MapComponent';

const HospitalFinder: React.FC = () => {
  return (
    <div className="pt-28 pb-16 container mx-auto px-4">
      <div className="mb-12">
        <div>
          <h1 className="text-3xl font-bold mb-2">Hospital Finder</h1>
          <p className="text-gray-600 max-w-3xl">
            Find healthcare facilities with detailed information on services, specialties, and pricing transparency.
          </p>
        </div>
        
        <div className="mt-6 flex items-center text-sm">
          <a href="/" className="text-gray-500 hover:text-[#457B9D]">Home</a>
          <ChevronRight size={14} className="mx-2 text-gray-400" />
          <span className="text-[#457B9D]">Hospital Finder</span>
        </div>
      </div>
      
      {/* Search controls */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Location</label>
            <div className="relative">
              <MapPin size={18} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input 
                type="text" 
                placeholder="Enter city or zip code" 
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#457B9D]"
                defaultValue="New York, NY"
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Specialty</label>
            <select className="w-full px-4 py-2 border border-gray-300 rounded-md bg-white focus:outline-none focus:ring-2 focus:ring-[#457B9D]">
              <option value="">All Specialties</option>
              <option value="cardiology">Cardiology</option>
              <option value="orthopedics">Orthopedics</option>
              <option value="neurology">Neurology</option>
              <option value="oncology">Oncology</option>
              <option value="pediatrics">Pediatrics</option>
              <option value="emergency">Emergency Medicine</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Payment Type</label>
            <select className="w-full px-4 py-2 border border-gray-300 rounded-md bg-white focus:outline-none focus:ring-2 focus:ring-[#457B9D]">
              <option value="">All Payment Types</option>
              <option value="insurance">Insurance</option>
              <option value="medicare">Medicare</option>
              <option value="medicaid">Medicaid</option>
              <option value="self-pay">Self-Pay</option>
            </select>
          </div>
        </div>
        
        <div className="mt-6 flex justify-end">
          <button className="bg-[#E63946] text-white px-4 py-2 rounded-md hover:bg-opacity-90 transition-colors">
            Search Hospitals
          </button>
        </div>
      </div>
      
      {/* Map component */}
      <MapComponent />
      
      {/* Information about hospital pricing */}
      <div className="mt-12 bg-blue-50 border border-blue-200 rounded-lg p-6">
        <h2 className="text-xl font-bold text-blue-800 mb-4">Understanding Hospital Pricing</h2>
        <p className="text-blue-800 mb-4">
          Hospital charges can vary significantly based on insurance coverage, services provided, and individual circumstances. The pricing information provided is an estimate and may not reflect your actual costs.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
          <div className="bg-white rounded-lg p-4 shadow-sm">
            <h3 className="font-medium text-gray-800 mb-2">Insurance</h3>
            <p className="text-sm text-gray-600">
              Costs shown are average negotiated rates. Your specific insurance plan may have different coverage and out-of-pocket expenses.
            </p>
          </div>
          <div className="bg-white rounded-lg p-4 shadow-sm">
            <h3 className="font-medium text-gray-800 mb-2">Medicare/Medicaid</h3>
            <p className="text-sm text-gray-600">
              Costs shown are based on standard Medicare and Medicaid reimbursement rates, which may vary by region.
            </p>
          </div>
          <div className="bg-white rounded-lg p-4 shadow-sm">
            <h3 className="font-medium text-gray-800 mb-2">Self-Pay</h3>
            <p className="text-sm text-gray-600">
              Costs shown are standard cash prices. Many hospitals offer discounts for self-pay patients or financial assistance programs.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HospitalFinder;