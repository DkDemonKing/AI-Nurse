import React, { useState } from 'react';
import { Users, ChevronRight, Check } from 'lucide-react';
import Button from '../ui/Button';
import Badge from '../ui/Badge';

const DataGeneration: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'patient' | 'test' | 'compliance'>('patient');
  
  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          <div className="lg:w-1/2">
            <div className="mb-8">
              <Badge variant="primary">Advanced Data Generation</Badge>
              <h2 className="text-3xl md:text-4xl font-bold mt-3 mb-4">Synthetic Patient Data for Healthcare Innovation</h2>
              <p className="text-gray-600 text-lg">
                Generate comprehensive and realistic patient data that maintains privacy while enabling healthcare applications to be thoroughly tested.
              </p>
            </div>
            
            <div className="flex border-b border-gray-200 mb-6">
              <TabButton 
                active={activeTab === 'patient'} 
                onClick={() => setActiveTab('patient')}
                icon={<Users size={16} />}
                label="Patient Profiles"
              />
              <TabButton 
                active={activeTab === 'test'} 
                onClick={() => setActiveTab('test')}
                icon={<Users size={16} />}
                label="Test Cases"
              />
              <TabButton 
                active={activeTab === 'compliance'} 
                onClick={() => setActiveTab('compliance')}
                icon={<Users size={16} />}
                label="Compliance"
              />
            </div>
            
            {activeTab === 'patient' && (
              <div className="space-y-4 mb-8">
                <Feature text="Generate diverse patient demographics including age, gender, and ethnicity" />
                <Feature text="Create realistic medical histories with conditions and past treatments" />
                <Feature text="Simulate lab results with appropriate reference ranges" />
                <Feature text="Include medications, allergies, and treatments" />
              </div>
            )}
            
            {activeTab === 'test' && (
              <div className="space-y-4 mb-8">
                <Feature text="Create functional test scripts for healthcare applications" />
                <Feature text="Generate edge cases for thorough application testing" />
                <Feature text="Simulate user interactions with medical systems" />
                <Feature text="Ensure comprehensive test coverage" />
              </div>
            )}
            
            {activeTab === 'compliance' && (
              <div className="space-y-4 mb-8">
                <Feature text="All data is HIPAA compliant by design" />
                <Feature text="Meets GDPR requirements for data privacy" />
                <Feature text="Includes audit trails for compliance verification" />
                <Feature text="Safe for use in regulated healthcare environments" />
              </div>
            )}
            
            <Button size="lg" icon={<ChevronRight size={16} />} iconPosition="right">
              Learn More
            </Button>
          </div>
          
          <div className="lg:w-1/2">
            <div className="bg-white rounded-xl shadow-lg overflow-hidden">
              <div className="p-2 bg-gray-50 border-b flex items-center gap-2">
                <div className="h-3 w-3 rounded-full bg-red-500"></div>
                <div className="h-3 w-3 rounded-full bg-yellow-500"></div>
                <div className="h-3 w-3 rounded-full bg-green-500"></div>
                <div className="text-xs text-gray-500 ml-2">patient-data-generator.js</div>
              </div>
              
              <pre className="p-4 text-sm overflow-x-auto">
                <code className="text-gray-800">
{`// FlorAIges_Medizone Patient Data Generator
import { generatePatient } from './generators';

const patientProfile = generatePatient({
  age: { min: 25, max: 85 },
  gender: ['male', 'female', 'non-binary'],
  conditions: ['diabetes', 'hypertension'],
  includeLabResults: true,
});

// Sample Output
{
  id: "PT-20250428-00127",
  name: "Maria J. Rodriguez",
  age: 67,
  gender: "female",
  symptoms: [
    "fatigue", 
    "increased thirst",
    "frequent urination"
  ],
  medicalHistory: "Type 2 Diabetes (10 years), Hypertension",
  labResults: {
    "HbA1c": 7.4,
    "Fasting Glucose": 142,
    "Blood Pressure": "138/88",
    "Cholesterol": {
      "Total": 195,
      "HDL": 52,
      "LDL": 110
    }
  },
  diagnosis: "Type 2 Diabetes, Controlled Hypertension",
  treatments: [
    "Metformin 1000mg daily",
    "Lisinopril 10mg daily",
    "Diet and exercise plan"
  ]
}`}
                </code>
              </pre>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

interface TabButtonProps {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
}

const TabButton: React.FC<TabButtonProps> = ({ active, onClick, icon, label }) => {
  return (
    <button
      className={`flex items-center px-4 py-3 font-medium text-sm border-b-2 -mb-px ${
        active 
          ? 'text-[#E63946] border-[#E63946]' 
          : 'text-gray-500 border-transparent hover:text-gray-700 hover:border-gray-300'
      }`}
      onClick={onClick}
    >
      <span className="mr-2">{icon}</span>
      {label}
    </button>
  );
};

interface FeatureProps {
  text: string;
}

const Feature: React.FC<FeatureProps> = ({ text }) => {
  return (
    <div className="flex items-start">
      <div className="flex-shrink-0 h-5 w-5 rounded-full bg-green-100 text-green-500 flex items-center justify-center mt-1 mr-3">
        <Check size={14} />
      </div>
      <p className="text-gray-700">{text}</p>
    </div>
  );
};

export default DataGeneration;