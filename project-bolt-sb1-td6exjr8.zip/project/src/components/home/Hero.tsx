import React from 'react';
import { Activity, Database, Lock, BarChart } from 'lucide-react';
import Button from '../ui/Button';
import { Link } from 'react-router-dom';

const Hero: React.FC = () => {
  return (
    <div className="relative bg-gradient-to-b from-[#f8f9fa] to-white pt-28 pb-16 md:pt-32 md:pb-24">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-12 md:mb-0">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-4">
              <span className="text-[#E63946]">FlorAIges</span>
              <span className="text-[#457B9D]">_Medizone</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-600 mb-6">
              Advanced medical data generation and testing platform with privacy compliance built-in.
            </p>
            <p className="text-gray-600 mb-8 max-w-lg">
              Generate synthetic patient profiles, automate test cases, and ensure HIPAA/GDPR compliance—all in one powerful platform.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/patient-data">
                <Button size="lg">Get Started</Button>
              </Link>
              <Link to="/documentation">
                <Button variant="outline" size="lg">Documentation</Button>
              </Link>
            </div>
            
            <div className="flex flex-wrap gap-8 mt-12">
              <FeaturePoint icon={<Database />} text="Synthetic Data" />
              <FeaturePoint icon={<BarChart />} text="Test Automation" />
              <FeaturePoint icon={<Lock />} text="HIPAA Compliant" />
            </div>
          </div>
          
          <div className="md:w-1/2 md:pl-8">
            <div className="relative">
              <div className="rounded-lg overflow-hidden shadow-xl transform transition-transform hover:scale-105 duration-300">
                <img 
                  src="https://images.pexels.com/photos/7089401/pexels-photo-7089401.jpeg" 
                  alt="Medical professional using FlorAIges_Medizone" 
                  className="w-full h-full object-cover rounded-lg"
                />
              </div>
              
              <div className="absolute -bottom-6 -left-6 bg-white rounded-lg shadow-lg p-4 w-40">
                <div className="flex items-center mb-2">
                  <Activity className="h-5 w-5 text-[#E63946] mr-2" />
                  <span className="text-sm font-semibold">Data Generated</span>
                </div>
                <div className="text-2xl font-bold text-[#457B9D]">10.5M+</div>
                <div className="text-xs text-gray-500">Patient Profiles</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-white to-transparent"></div>
    </div>
  );
};

interface FeaturePointProps {
  icon: React.ReactNode;
  text: string;
}

const FeaturePoint: React.FC<FeaturePointProps> = ({ icon, text }) => {
  return (
    <div className="flex items-center">
      <div className="flex items-center justify-center bg-[#E63946] bg-opacity-10 text-[#E63946] h-10 w-10 rounded-full mr-3">
        {icon}
      </div>
      <span className="text-gray-700 font-medium">{text}</span>
    </div>
  );
};

export default Hero;