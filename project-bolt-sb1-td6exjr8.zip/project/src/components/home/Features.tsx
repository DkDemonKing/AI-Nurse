import React from 'react';
import { Users, FileSearch, ShieldCheck, MapPin, Fingerprint } from 'lucide-react';
import Card, { CardContent, CardHeader } from '../ui/Card';

const Features: React.FC = () => {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Comprehensive Healthcare Data Platform</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Our platform offers a complete suite of tools for healthcare data generation, testing, and compliance.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <FeatureCard 
            icon={<Users size={24} />}
            title="Synthetic Patient Data"
            description="Generate diverse patient profiles with realistic demographic information, symptoms, medical history, lab results, diagnoses, and treatments."
          />
          
          <FeatureCard 
            icon={<FileSearch size={24} />}
            title="Test Case Automation"
            description="Develop functional test scripts and edge cases specifically designed for healthcare applications and systems."
          />
          
          <FeatureCard 
            icon={<ShieldCheck size={24} />}
            title="Privacy Compliance"
            description="Ensure all generated data is fully HIPAA and GDPR compliant, protecting sensitive patient information while enabling testing."
          />
          
          <FeatureCard 
            icon={<MapPin size={24} />}
            title="Hospital Finder"
            description="Locate healthcare facilities with detailed information on services, specialties, and complete pricing transparency for all payment types."
          />
          
          <FeatureCard 
            icon={<Fingerprint size={24} />}
            title="Biometric Authentication"
            description="Secure access to patient data with advanced biometric authentication, ensuring only authorized personnel can access sensitive information."
          />

          <div className="relative overflow-hidden rounded-lg shadow-lg h-full bg-gradient-to-br from-[#457B9D] to-[#2DD3BF] text-white">
            <div className="absolute inset-0 bg-opacity-90 flex items-center justify-center">
              <div className="p-8 text-center">
                <h3 className="text-2xl font-bold mb-4">Ready to transform your healthcare testing?</h3>
                <p className="mb-6">Join thousands of healthcare organizations already using our platform.</p>
                <button className="bg-white text-[#457B9D] px-6 py-3 rounded-md font-medium hover:bg-gray-100 transition-colors">
                  Request Demo
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ icon, title, description }) => {
  return (
    <Card className="h-full transition-transform hover:translate-y-[-5px] duration-300">
      <CardHeader
        title={title}
        icon={icon}
      />
      <CardContent>
        <p className="text-gray-600">{description}</p>
      </CardContent>
    </Card>
  );
};

export default Features;