import React from 'react';
import { Activity, Heart, Mail, Phone, MapPin } from 'lucide-react';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
  return (
    <footer className="bg-[#f8f9fa] pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Activity className="h-6 w-6 text-[#E63946]" />
              <span className="text-xl font-bold">
                <span className="text-[#E63946]">FlorAIges</span>
                <span className="text-[#457B9D]">_Medizone</span>
              </span>
            </div>
            <p className="text-gray-600 mb-4">
              Advanced synthetic medical data generation platform ensuring HIPAA/GDPR compliance while facilitating healthcare application testing.
            </p>
            <div className="flex space-x-4">
              <SocialIcon icon="twitter" />
              <SocialIcon icon="facebook" />
              <SocialIcon icon="linkedin" />
              <SocialIcon icon="instagram" />
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <FooterLink href="/patient-data" label="Patient Data" />
              <FooterLink href="/test-cases" label="Test Cases" />
              <FooterLink href="/compliance" label="Compliance" />
              <FooterLink href="/hospital-finder" label="Hospital Finder" />
              <FooterLink href="/biometrics" label="Biometrics" />
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Resources</h3>
            <ul className="space-y-2">
              <FooterLink href="/documentation" label="Documentation" />
              <FooterLink href="/api" label="API" />
              <FooterLink href="/blog" label="Blog" />
              <FooterLink href="/faq" label="FAQ" />
              <FooterLink href="/support" label="Support" />
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-2">
                <MapPin className="h-5 w-5 text-[#E63946] mt-0.5" />
                <span className="text-gray-600">123 Medical Plaza, Healthcare District, NY 10001</span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="h-5 w-5 text-[#E63946]" />
                <span className="text-gray-600">+1 (555) 123-4567</span>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="h-5 w-5 text-[#E63946]" />
                <span className="text-gray-600">contact@floraiges-medizone.com</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-200 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-500 text-sm mb-4 md:mb-0">
            &copy; {new Date().getFullYear()} FlorAIges_Medizone. All rights reserved.
          </p>
          <div className="flex space-x-6">
            <Link to="/privacy" className="text-gray-500 text-sm hover:text-[#E63946] transition-colors">
              Privacy Policy
            </Link>
            <Link to="/terms" className="text-gray-500 text-sm hover:text-[#E63946] transition-colors">
              Terms of Service
            </Link>
            <Link to="/cookies" className="text-gray-500 text-sm hover:text-[#E63946] transition-colors">
              Cookie Policy
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

interface FooterLinkProps {
  href: string;
  label: string;
}

const FooterLink: React.FC<FooterLinkProps> = ({ href, label }) => {
  return (
    <li>
      <Link to={href} className="text-gray-600 hover:text-[#E63946] transition-colors">
        {label}
      </Link>
    </li>
  );
};

interface SocialIconProps {
  icon: string;
}

const SocialIcon: React.FC<SocialIconProps> = ({ icon }) => {
  return (
    <a 
      href={`https://${icon}.com`} 
      target="_blank" 
      rel="noopener noreferrer"
      className="h-8 w-8 rounded-full bg-[#457B9D] text-white flex items-center justify-center hover:bg-[#E63946] transition-colors"
    >
      <span className="sr-only">{icon}</span>
      <i className={`fab fa-${icon}`}></i>
    </a>
  );
};

export default Footer;