import React, { useState, useEffect } from 'react';
import { Menu, X, Activity, User, FileText, Shield, MapPin, Fingerprint } from 'lucide-react';
import { Link } from 'react-router-dom';
import NotificationCenter from '../notifications/NotificationCenter';

const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4 flex justify-between items-center">
        <Link to="/" className="flex items-center gap-2">
          <Activity className="h-8 w-8 text-[#E63946]" />
          <span className="text-xl font-bold">
            <span className="text-[#E63946]">FlorAIges</span>
            <span className="text-[#457B9D]">_Medizone</span>
          </span>
        </Link>

        {/* Desktop menu */}
        <nav className="hidden md:flex items-center space-x-8">
          <NavLink href="/" label="Home" />
          <NavLink href="/patient-data" label="Patient Data" icon={<User className="h-4 w-4" />} />
          <NavLink href="/test-cases" label="Test Cases" icon={<FileText className="h-4 w-4" />} />
          <NavLink href="/compliance" label="Compliance" icon={<Shield className="h-4 w-4" />} />
          <NavLink href="/hospital-finder" label="Hospital Finder" icon={<MapPin className="h-4 w-4" />} />
          <NavLink href="/biometrics" label="Biometrics" icon={<Fingerprint className="h-4 w-4" />} />
          <NotificationCenter />
        </nav>

        <button 
          className="md:hidden text-[#457B9D]"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white shadow-lg absolute top-full left-0 right-0 py-4 px-4">
          <nav className="flex flex-col space-y-4">
            <MobileNavLink href="/" label="Home" onClick={() => setMobileMenuOpen(false)} />
            <MobileNavLink href="/patient-data" label="Patient Data" onClick={() => setMobileMenuOpen(false)} />
            <MobileNavLink href="/test-cases" label="Test Cases" onClick={() => setMobileMenuOpen(false)} />
            <MobileNavLink href="/compliance" label="Compliance" onClick={() => setMobileMenuOpen(false)} />
            <MobileNavLink href="/hospital-finder" label="Hospital Finder" onClick={() => setMobileMenuOpen(false)} />
            <MobileNavLink href="/biometrics" label="Biometrics" onClick={() => setMobileMenuOpen(false)} />
          </nav>
        </div>
      )}
    </header>
  );
};

interface NavLinkProps {
  href: string;
  label: string;
  icon?: React.ReactNode;
}

const NavLink: React.FC<NavLinkProps> = ({ href, label, icon }) => {
  return (
    <Link 
      to={href} 
      className="text-[#457B9D] hover:text-[#E63946] transition-colors flex items-center gap-1"
    >
      {icon}
      <span>{label}</span>
    </Link>
  );
};

interface MobileNavLinkProps extends NavLinkProps {
  onClick: () => void;
}

const MobileNavLink: React.FC<MobileNavLinkProps> = ({ href, label, onClick }) => {
  return (
    <Link 
      to={href} 
      className="text-[#457B9D] hover:text-[#E63946] transition-colors block py-2"
      onClick={onClick}
    >
      {label}
    </Link>
  );
};

export default Header;