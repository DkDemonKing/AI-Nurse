import React, { useState, useEffect } from 'react';
import { Fingerprint, Scan, CheckCircle, AlertCircle, RotateCw } from 'lucide-react';
import Button from '../ui/Button';
import { BiometricScan } from '../../types';

const BiometricScanner: React.FC = () => {
  const [scanning, setScanning] = useState(false);
  const [scanComplete, setScanComplete] = useState(false);
  const [scanSuccess, setScanSuccess] = useState(false);
  const [scanHistory, setScanHistory] = useState<BiometricScan[]>([]);
  
  const startScan = () => {
    setScanning(true);
    setScanComplete(false);
    
    // Simulate a scanner processing time
    setTimeout(() => {
      setScanning(false);
      setScanComplete(true);
      
      // 80% chance of success for demo purposes
      const success = Math.random() > 0.2;
      setScanSuccess(success);
      
      // Add to scan history
      const newScan: BiometricScan = {
        id: Date.now().toString(),
        type: 'fingerprint',
        status: success ? 'completed' : 'failed',
        timestamp: new Date().toISOString(),
        result: success ? 'Authentication successful' : 'Authentication failed'
      };
      
      setScanHistory(prev => [newScan, ...prev]);
    }, 3000);
  };
  
  const resetScan = () => {
    setScanComplete(false);
    setScanSuccess(false);
  };
  
  useEffect(() => {
    // Initialize with some sample history
    setScanHistory([
      {
        id: '1',
        type: 'fingerprint',
        status: 'completed',
        timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(), // 1 day ago
        result: 'Authentication successful'
      },
      {
        id: '2',
        type: 'fingerprint',
        status: 'failed',
        timestamp: new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString(), // 2 days ago
        result: 'Authentication failed'
      }
    ]);
  }, []);

  return (
    <div className="max-w-4xl mx-auto">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Scanner visualization */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="p-6 border-b border-gray-100">
            <h2 className="text-2xl font-bold text-gray-800 flex items-center">
              <Fingerprint className="mr-2 text-[#E63946]" />
              Biometric Authentication
            </h2>
            <p className="text-gray-600 mt-2">
              Secure access to patient records and medical data
            </p>
          </div>
          
          <div className="p-8 flex flex-col items-center">
            <div className="relative w-64 h-64 mb-8">
              {/* Scanner visual */}
              <div 
                className={`w-full h-full rounded-lg border-4 ${
                  scanComplete 
                    ? scanSuccess 
                      ? 'border-green-500' 
                      : 'border-red-500' 
                    : 'border-[#457B9D]'
                } flex items-center justify-center relative overflow-hidden`}
              >
                <Fingerprint 
                  size={120} 
                  className={`${
                    scanComplete 
                      ? scanSuccess 
                        ? 'text-green-500' 
                        : 'text-red-500' 
                      : 'text-[#457B9D]'
                  }`} 
                />
                
                {/* Scanning animation */}
                {scanning && (
                  <div className="absolute inset-0">
                    <div className="h-2 bg-[#2DD3BF] bg-opacity-30 w-full absolute top-0 animate-scan"></div>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="animate-pulse">
                        <Scan size={140} className="text-[#2DD3BF] opacity-40" />
                      </div>
                    </div>
                  </div>
                )}
                
                {/* Success/Failure indicators */}
                {scanComplete && (
                  <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-5">
                    {scanSuccess ? (
                      <div className="text-center">
                        <CheckCircle size={48} className="text-green-500 mx-auto mb-2" />
                        <p className="text-green-600 font-medium">Authentication Successful</p>
                      </div>
                    ) : (
                      <div className="text-center">
                        <AlertCircle size={48} className="text-red-500 mx-auto mb-2" />
                        <p className="text-red-600 font-medium">Authentication Failed</p>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
            
            <div className="flex gap-4">
              {!scanning && !scanComplete && (
                <Button 
                  size="lg" 
                  onClick={startScan}
                  icon={<Fingerprint size={18} />}
                >
                  Start Scan
                </Button>
              )}
              
              {scanning && (
                <Button 
                  size="lg" 
                  variant="secondary"
                  disabled
                  icon={<RotateCw size={18} className="animate-spin" />}
                >
                  Scanning...
                </Button>
              )}
              
              {scanComplete && (
                <Button 
                  size="lg" 
                  variant={scanSuccess ? "outline" : "primary"}
                  onClick={resetScan}
                >
                  {scanSuccess ? "New Scan" : "Try Again"}
                </Button>
              )}
            </div>
          </div>
        </div>
        
        {/* Scan history and information */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="p-6 border-b border-gray-100">
            <h2 className="text-2xl font-bold text-gray-800">Authentication History</h2>
            <p className="text-gray-600 mt-2">
              Recent biometric authentication attempts
            </p>
          </div>
          
          <div className="p-6">
            <div className="space-y-4">
              {scanHistory.map((scan) => (
                <div 
                  key={scan.id} 
                  className="border border-gray-100 rounded-lg p-4 hover:bg-gray-50 transition-colors"
                >
                  <div className="flex justify-between items-start">
                    <div className="flex items-start">
                      <div className={`p-2 rounded-full mr-3 ${
                        scan.status === 'completed' ? 'bg-green-100' : 'bg-red-100'
                      }`}>
                        <Fingerprint size={20} className={
                          scan.status === 'completed' ? 'text-green-600' : 'text-red-600'
                        } />
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-800">
                          {scan.status === 'completed' ? 'Authentication Successful' : 'Authentication Failed'}
                        </h4>
                        <p className="text-sm text-gray-500 mt-1">
                          {new Date(scan.timestamp).toLocaleString()}
                        </p>
                      </div>
                    </div>
                    <div>
                      {scan.status === 'completed' ? (
                        <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">
                          Success
                        </span>
                      ) : (
                        <span className="bg-red-100 text-red-800 text-xs px-2 py-1 rounded-full">
                          Failed
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
              
              {scanHistory.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  No authentication history yet
                </div>
              )}
            </div>
          </div>
          
          <div className="bg-gray-50 p-6">
            <h3 className="font-medium text-gray-800 mb-3">About Biometric Authentication</h3>
            <p className="text-gray-600 text-sm mb-4">
              Our system uses advanced biometric authentication to ensure only authorized personnel can access sensitive patient data. This helps maintain HIPAA and GDPR compliance while providing a seamless authentication experience.
            </p>
            <h4 className="font-medium text-gray-800 mb-2">Supported Methods:</h4>
            <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
              <li>Fingerprint scanning</li>
              <li>Facial recognition</li>
              <li>Voice authentication</li>
              <li>Retina scanning</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BiometricScanner;