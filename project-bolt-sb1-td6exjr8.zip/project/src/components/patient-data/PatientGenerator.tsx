import React, { useState } from 'react';
import { RefreshCw, Download, CheckSquare, Settings } from 'lucide-react';
import Card, { CardContent, CardHeader, CardFooter } from '../ui/Card';
import Button from '../ui/Button';
import Badge from '../ui/Badge';

// This would normally come from your data service
const generateRandomPatient = () => {
  const genders = ['Male', 'Female', 'Non-binary'];
  const symptoms = [
    'Fatigue', 'Headache', 'Dizziness', 'Nausea', 'Fever', 'Cough', 
    'Shortness of breath', 'Chest pain', 'Abdominal pain', 'Joint pain'
  ];
  const diagnoses = [
    'Hypertension', 'Type 2 Diabetes', 'Migraine', 'Seasonal Allergies',
    'Asthma', 'Anxiety Disorder', 'Gastroesophageal Reflux Disease',
    'Osteoarthritis', 'Hypothyroidism', 'Upper Respiratory Infection'
  ];
  const treatments = [
    'Amlodipine 5mg daily', 'Metformin 1000mg twice daily',
    'Sumatriptan 50mg as needed', 'Cetirizine 10mg daily',
    'Albuterol inhaler 2 puffs as needed', 'Sertraline 50mg daily',
    'Omeprazole 20mg daily', 'Acetaminophen 500mg as needed',
    'Levothyroxine 50mcg daily', 'Amoxicillin 500mg three times daily for 10 days'
  ];

  // Random selection helpers
  const randomAge = Math.floor(Math.random() * 70) + 18;
  const randomGender = genders[Math.floor(Math.random() * genders.length)];
  const randomSymptoms = Array.from({ length: Math.floor(Math.random() * 3) + 1 }, () => 
    symptoms[Math.floor(Math.random() * symptoms.length)]
  );
  const randomDiagnosis = diagnoses[Math.floor(Math.random() * diagnoses.length)];
  const randomTreatments = Array.from({ length: Math.floor(Math.random() * 2) + 1 }, () => 
    treatments[Math.floor(Math.random() * treatments.length)]
  );

  return {
    id: `PT-${Date.now().toString().slice(-6)}`,
    name: "John Doe", // In a real app, you'd generate realistic names
    age: randomAge,
    gender: randomGender,
    symptoms: [...new Set(randomSymptoms)],
    medicalHistory: "Prior medical history would be generated here",
    labResults: {
      "Blood Pressure": `${Math.floor(Math.random() * 40) + 100}/${Math.floor(Math.random() * 30) + 60}`,
      "Heart Rate": `${Math.floor(Math.random() * 40) + 60} bpm`,
      "Temperature": `${(Math.random() * 1.5 + 36).toFixed(1)}°C`,
    },
    diagnosis: randomDiagnosis,
    treatments: [...new Set(randomTreatments)],
    createdAt: new Date().toISOString()
  };
};

const PatientGenerator: React.FC = () => {
  const [patient, setPatient] = useState(generateRandomPatient());
  const [loading, setLoading] = useState(false);

  const handleGeneratePatient = () => {
    setLoading(true);
    
    // Simulate API call delay
    setTimeout(() => {
      setPatient(generateRandomPatient());
      setLoading(false);
    }, 800);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-800">Patient Profile Generator</h2>
          <Button 
            variant="primary" 
            icon={<RefreshCw size={16} className={loading ? 'animate-spin' : ''} />} 
            onClick={handleGeneratePatient}
            disabled={loading}
          >
            Generate New Profile
          </Button>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left column - Patient Info */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader 
                title="Patient Information" 
                icon={<Settings size={18} />}
              />
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Patient ID</label>
                    <div className="text-gray-900 font-medium">{patient.id}</div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Name</label>
                    <div className="text-gray-900">{patient.name}</div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Age</label>
                      <div className="text-gray-900">{patient.age} years</div>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Gender</label>
                      <div className="text-gray-900">{patient.gender}</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Right column - Medical Data */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader 
                title="Medical Data" 
                icon={<CheckSquare size={18} />}
              />
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Symptoms</label>
                    <div className="flex flex-wrap gap-2">
                      {patient.symptoms.map((symptom, index) => (
                        <Badge key={index} variant="secondary">{symptom}</Badge>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Lab Results</label>
                    <div className="bg-gray-50 rounded p-3 text-sm">
                      {Object.entries(patient.labResults).map(([key, value]) => (
                        <div key={key} className="flex justify-between py-1 border-b border-gray-100 last:border-0">
                          <span className="text-gray-600">{key}:</span>
                          <span className="font-medium">{value}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Diagnosis</label>
                    <div className="text-gray-900 font-medium">{patient.diagnosis}</div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Treatments</label>
                    <ul className="list-disc list-inside text-gray-700 space-y-1">
                      {patient.treatments.map((treatment, index) => (
                        <li key={index}>{treatment}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <div className="flex justify-end">
                  <Button 
                    variant="outline" 
                    icon={<Download size={16} />} 
                    onClick={() => alert('Download functionality would be implemented here')}
                  >
                    Export Profile
                  </Button>
                </div>
              </CardFooter>
            </Card>
          </div>
        </div>
      </div>
      
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-blue-800 text-sm">
        <p>
          <strong>Note:</strong> This is a demo of synthetic patient data generation. In a production environment, 
          you would have more options to customize the data generation process and ensure HIPAA/GDPR compliance.
        </p>
      </div>
    </div>
  );
};

export default PatientGenerator;