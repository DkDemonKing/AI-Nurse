import React, { useEffect, useState } from 'react';
import { MapPin, Phone, DollarSign, Star } from 'lucide-react';
import Card, { CardContent, CardHeader } from '../ui/Card';
import Badge from '../ui/Badge';
import Button from '../ui/Button';
import { Hospital } from '../../types';

// Sample hospital data
const sampleHospitals: Hospital[] = [
  {
    id: "h1",
    name: "Memorial Medical Center",
    address: "123 Healthcare Ave, New York, NY 10001",
    coordinates: { lat: 40.7128, lng: -74.006 },
    specialties: ["Cardiology", "Oncology", "Neurology"],
    paymentOptions: [
      { type: "Insurance", averageCost: 2500 },
      { type: "Self-pay", averageCost: 3200 },
      { type: "Medicare", averageCost: 1800 }
    ],
    rating: 4.7,
    phone: "+1 (555) 123-4567"
  },
  {
    id: "h2",
    name: "City General Hospital",
    address: "456 Medical Blvd, New York, NY 10002",
    coordinates: { lat: 40.7282, lng: -73.994 },
    specialties: ["Emergency Medicine", "Pediatrics", "Surgery"],
    paymentOptions: [
      { type: "Insurance", averageCost: 2200 },
      { type: "Self-pay", averageCost: 2800 },
      { type: "Medicare", averageCost: 1600 }
    ],
    rating: 4.5,
    phone: "+1 (555) 234-5678"
  },
  {
    id: "h3",
    name: "University Health System",
    address: "789 Research Way, New York, NY 10003",
    coordinates: { lat: 40.7369, lng: -73.988 },
    specialties: ["Orthopedics", "Psychiatry", "Dermatology"],
    paymentOptions: [
      { type: "Insurance", averageCost: 2800 },
      { type: "Self-pay", averageCost: 3500 },
      { type: "Medicare", averageCost: 2000 }
    ],
    rating: 4.9,
    phone: "+1 (555) 345-6789"
  }
];

const MapComponent: React.FC = () => {
  const [selectedHospital, setSelectedHospital] = useState<Hospital | null>(null);
  const [mapLoaded, setMapLoaded] = useState(false);
  const [hospitals] = useState<Hospital[]>(sampleHospitals);

  useEffect(() => {
    // In a real implementation, this would load the Google Maps API
    // and initialize the map
    const timer = setTimeout(() => {
      setMapLoaded(true);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  // In a real implementation, this would handle map clicks
  // and show hospital details
  const handleHospitalSelect = (hospital: Hospital) => {
    setSelectedHospital(hospital);
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="flex flex-col lg:flex-row h-[600px]">
        {/* Left side - Map */}
        <div className="lg:w-2/3 h-full relative bg-gray-200">
          {!mapLoaded ? (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#E63946]"></div>
            </div>
          ) : (
            <div className="h-full">
              {/* This would be where the Google Maps would render */}
              <div className="h-full flex flex-col items-center justify-center p-4 text-center text-gray-500">
                <MapPin size={48} className="text-[#E63946] mb-4" />
                <p className="mb-4">Google Maps would render here with hospital locations</p>
                <p className="text-sm">
                  In a production environment, this would use the Google Maps JavaScript API to show interactive hospital locations
                </p>
              </div>
              
              {/* Mini hospital cards that would overlay on the map */}
              <div className="absolute top-4 left-4">
                {hospitals.map((hospital) => (
                  <div 
                    key={hospital.id} 
                    className="bg-white rounded-md shadow-md p-3 mb-2 cursor-pointer hover:bg-gray-50 transition-colors"
                    onClick={() => handleHospitalSelect(hospital)}
                  >
                    <div className="font-medium text-gray-800">{hospital.name}</div>
                    <div className="text-sm text-gray-500">{hospital.address.split(',')[0]}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
        
        {/* Right side - Hospital details */}
        <div className="lg:w-1/3 overflow-auto">
          {selectedHospital ? (
            <div className="p-4">
              <h3 className="text-xl font-bold text-gray-800 mb-2">{selectedHospital.name}</h3>
              
              <div className="flex items-center mb-4">
                <div className="flex items-center text-yellow-500 mr-2">
                  <Star size={18} className="fill-current" />
                  <span className="ml-1 font-medium">{selectedHospital.rating}</span>
                </div>
                <span className="text-sm text-gray-500">★★★★★</span>
              </div>
              
              <div className="flex items-start mb-4">
                <MapPin size={18} className="text-gray-400 mt-1 mr-2" />
                <span className="text-gray-600">{selectedHospital.address}</span>
              </div>
              
              <div className="flex items-center mb-6">
                <Phone size={18} className="text-gray-400 mr-2" />
                <a href={`tel:${selectedHospital.phone}`} className="text-[#457B9D] hover:underline">
                  {selectedHospital.phone}
                </a>
              </div>
              
              <div className="mb-6">
                <h4 className="font-medium text-gray-800 mb-2">Specialties</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedHospital.specialties.map((specialty, idx) => (
                    <Badge key={idx} variant="secondary">{specialty}</Badge>
                  ))}
                </div>
              </div>
              
              <div className="mb-6">
                <h4 className="font-medium text-gray-800 mb-2">Payment Options & Costs</h4>
                <div className="space-y-3">
                  {selectedHospital.paymentOptions.map((payment, idx) => (
                    <div key={idx} className="flex justify-between items-center bg-gray-50 p-3 rounded">
                      <div className="flex items-center">
                        <DollarSign size={16} className="text-gray-400 mr-2" />
                        <span>{payment.type}</span>
                      </div>
                      <span className="font-medium">${payment.averageCost.toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="flex space-x-3">
                <Button>Get Directions</Button>
                <Button variant="outline">Request Appointment</Button>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-full p-8 text-center">
              <MapPin size={48} className="text-gray-300 mb-4" />
              <h3 className="text-xl font-medium text-gray-700 mb-2">Select a Hospital</h3>
              <p className="text-gray-500">
                Click on a hospital on the map to view detailed information including specialties and payment options.
              </p>
            </div>
          )}
        </div>
      </div>
      
      {/* List view of hospitals */}
      <div className="border-t border-gray-200">
        <div className="p-4">
          <h3 className="text-lg font-medium text-gray-800 mb-4">Nearby Hospitals</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {hospitals.map((hospital) => (
              <HospitalCard 
                key={hospital.id} 
                hospital={hospital} 
                onSelect={() => handleHospitalSelect(hospital)}
                isSelected={selectedHospital?.id === hospital.id}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

interface HospitalCardProps {
  hospital: Hospital;
  onSelect: () => void;
  isSelected: boolean;
}

const HospitalCard: React.FC<HospitalCardProps> = ({ hospital, onSelect, isSelected }) => {
  return (
    <Card 
      className={`cursor-pointer transition-all hover:shadow-md ${
        isSelected ? 'ring-2 ring-[#E63946] ring-opacity-50' : ''
      }`}
    >
      <CardHeader
        title={hospital.name}
        subtitle={
          <div className="flex items-center">
            <Star size={14} className="text-yellow-500 mr-1" />
            <span>{hospital.rating}</span>
          </div>
        }
      />
      <CardContent className="pt-0">
        <div className="text-sm text-gray-500 mb-3">
          <div className="flex items-start mb-2">
            <MapPin size={14} className="mt-1 mr-1 flex-shrink-0" />
            <span>{hospital.address.split(',')[0]}</span>
          </div>
          <div className="flex items-center">
            <Phone size={14} className="mr-1 flex-shrink-0" />
            <span>{hospital.phone}</span>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-1 mb-4">
          {hospital.specialties.slice(0, 2).map((specialty, idx) => (
            <Badge key={idx} variant="default" className="text-xs">{specialty}</Badge>
          ))}
          {hospital.specialties.length > 2 && (
            <Badge variant="default" className="text-xs">+{hospital.specialties.length - 2} more</Badge>
          )}
        </div>
        
        <Button 
          variant="outline" 
          className="w-full"
          onClick={onSelect}
        >
          View Details
        </Button>
      </CardContent>
    </Card>
  );
};

export default MapComponent;