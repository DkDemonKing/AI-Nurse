import React, { useEffect, useState } from 'react';
import { Bell, Clock, X } from 'lucide-react';
import { toast, Toaster } from 'react-hot-toast';
import { supabase } from '../../lib/supabase';

interface Reminder {
  id: string;
  title: string;
  description: string;
  time: string;
  type: 'medication' | 'appointment' | 'test';
}

const NotificationCenter: React.FC = () => {
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [showNotifications, setShowNotifications] = useState(false);

  useEffect(() => {
    fetchReminders();
    subscribeToReminders();
    checkReminders();

    // Check reminders every minute
    const interval = setInterval(checkReminders, 60000);
    return () => clearInterval(interval);
  }, []);

  const fetchReminders = async () => {
    try {
      const { data, error } = await supabase
        .from('reminders')
        .select('*')
        .order('time', { ascending: true });

      if (error) throw error;
      setReminders(data || []);
    } catch (error) {
      console.error('Error fetching reminders:', error);
    }
  };

  const subscribeToReminders = () => {
    supabase
      .channel('reminders')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'reminders' }, fetchReminders)
      .subscribe();
  };

  const checkReminders = () => {
    const now = new Date();
    reminders.forEach(reminder => {
      const reminderTime = new Date(reminder.time);
      if (reminderTime.getTime() - now.getTime() <= 300000 && reminderTime.getTime() > now.getTime()) { // 5 minutes before
        toast.custom((t) => (
          <div className={`${t.visible ? 'animate-enter' : 'animate-leave'} bg-white shadow-lg rounded-lg p-4 flex items-start max-w-md w-full`}>
            <div className="flex-shrink-0 mr-4">
              <Clock className="h-6 w-6 text-[#E63946]" />
            </div>
            <div className="flex-1">
              <h4 className="font-medium text-gray-900">{reminder.title}</h4>
              <p className="text-sm text-gray-600">{reminder.description}</p>
              <p className="text-xs text-gray-500 mt-1">
                {new Date(reminder.time).toLocaleTimeString()}
              </p>
            </div>
            <button onClick={() => toast.dismiss(t.id)} className="ml-4">
              <X className="h-4 w-4 text-gray-400" />
            </button>
          </div>
        ), { duration: 10000 });
      }
    });
  };

  return (
    <>
      <div className="relative">
        <button
          onClick={() => setShowNotifications(!showNotifications)}
          className="relative p-2 text-gray-600 hover:text-[#E63946] transition-colors"
        >
          <Bell className="h-6 w-6" />
          {reminders.length > 0 && (
            <span className="absolute top-0 right-0 h-4 w-4 bg-[#E63946] text-white text-xs flex items-center justify-center rounded-full">
              {reminders.length}
            </span>
          )}
        </button>

        {showNotifications && (
          <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-lg z-50">
            <div className="p-4 border-b border-gray-100">
              <h3 className="font-medium text-gray-900">Notifications</h3>
            </div>
            <div className="max-h-96 overflow-y-auto">
              {reminders.length > 0 ? (
                reminders.map(reminder => (
                  <div key={reminder.id} className="p-4 border-b border-gray-100 last:border-0">
                    <div className="flex items-start">
                      <Clock className="h-5 w-5 text-[#E63946] mt-0.5 mr-3" />
                      <div>
                        <h4 className="font-medium text-gray-900">{reminder.title}</h4>
                        <p className="text-sm text-gray-600">{reminder.description}</p>
                        <p className="text-xs text-gray-500 mt-1">
                          {new Date(reminder.time).toLocaleString()}
                        </p>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-4 text-center text-gray-500">
                  No notifications
                </div>
              )}
            </div>
          </div>
        )}
      </div>
      <Toaster position="top-right" />
    </>
  );
};

export default NotificationCenter;