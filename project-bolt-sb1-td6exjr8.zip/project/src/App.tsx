import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout/Layout';
import Home from './pages/Home';
import PatientData from './pages/PatientData';
import TestCases from './pages/TestCases';
import Compliance from './pages/Compliance';
import HospitalFinder from './pages/HospitalFinder';
import Biometrics from './pages/Biometrics';

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/patient-data" element={<PatientData />} />
          <Route path="/test-cases" element={<TestCases />} />
          <Route path="/compliance" element={<Compliance />} />
          <Route path="/hospital-finder" element={<HospitalFinder />} />
          <Route path="/biometrics" element={<Biometrics />} />
        </Routes>
      </Layout>
    </Router>
  );
}

export default App;