export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      reminders: {
        Row: {
          id: string
          title: string
          description: string | null
          time: string
          type: 'medication' | 'appointment' | 'test'
          user_id: string
          created_at: string
        }
        Insert: {
          id?: string
          title: string
          description?: string | null
          time: string
          type: 'medication' | 'appointment' | 'test'
          user_id: string
          created_at?: string
        }
        Update: {
          id?: string
          title?: string
          description?: string | null
          time?: string
          type?: 'medication' | 'appointment' | 'test'
          user_id?: string
          created_at?: string
        }
      }
    }
  }
}