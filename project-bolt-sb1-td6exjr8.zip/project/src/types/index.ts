export interface PatientProfile {
  id: string;
  name: string;
  age: number;
  gender: string;
  symptoms: string[];
  medicalHistory: string;
  labResults: Record<string, string | number>;
  diagnosis: string;
  treatments: string[];
  createdAt: string;
}

export interface TestCase {
  id: string;
  name: string;
  description: string;
  steps: string[];
  expectedResults: string[];
  category: string;
  createdAt: string;
}

export interface Hospital {
  id: string;
  name: string;
  address: string;
  coordinates: {
    lat: number;
    lng: number;
  };
  specialties: string[];
  paymentOptions: {
    type: string;
    averageCost: number;
  }[];
  rating: number;
  phone: string;
}

export interface BiometricScan {
  id: string;
  type: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  timestamp: string;
  result?: string;
}